// Script pour la fonctionnalité de changement de langue
document.addEventListener('DOMContentLoaded', function() {
    // Langue par défaut
    let currentLang = 'fr';
    
    // Récupérer le bouton de changement de langue
    const langToggle = document.getElementById('language-toggle');
    const langIcon = document.getElementById('language-icon');
    
    // Fonction pour changer la langue
    function toggleLanguage() {
        // Changer la langue courante
        currentLang = currentLang === 'fr' ? 'en' : 'fr';
        
        // Mettre à jour l'icône et le titre du bouton
        if (currentLang === 'fr') {
            langIcon.textContent = '🇬🇧';
            langToggle.title = 'Switch to English';
        } else {
            langIcon.textContent = '🇫🇷';
            langToggle.title = 'Passer en français';
        }
        
        // Mettre à jour l'affichage des éléments selon la langue
        document.querySelectorAll('[data-lang]').forEach(element => {
            if (element.getAttribute('data-lang') === currentLang) {
                element.style.display = '';
            } else {
                element.style.display = 'none';
            }
        });
        
        // Sauvegarder la préférence de langue dans localStorage
        localStorage.setItem('nhl25guide_lang', currentLang);
    }
    
    // Ajouter l'événement de clic au bouton
    if (langToggle) {
        langToggle.addEventListener('click', toggleLanguage);
    }
    
    // Charger la langue préférée depuis localStorage si disponible
    const savedLang = localStorage.getItem('nhl25guide_lang');
    if (savedLang) {
        currentLang = savedLang;
        if (currentLang === 'en') {
            langIcon.textContent = '🇫🇷';
            langToggle.title = 'Passer en français';
        }
    }
    
    // Appliquer la langue initiale
    document.querySelectorAll('[data-lang]').forEach(element => {
        if (element.getAttribute('data-lang') !== currentLang) {
            element.style.display = 'none';
        }
    });
});
