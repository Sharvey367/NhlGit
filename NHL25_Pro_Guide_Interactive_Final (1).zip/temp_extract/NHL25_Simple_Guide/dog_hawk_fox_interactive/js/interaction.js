// Script pour les interactions du diagramme Dog-Hawk-Fox

document.addEventListener('DOMContentLoaded', function() {
    // Gestion des clics sur les joueurs pour afficher les informations de rôle
    const dogPlayer = document.getElementById('dog-player');
    const hawkPlayer = document.getElementById('hawk-player');
    const foxPlayer = document.getElementById('fox-player');
    
    const dogDetails = document.getElementById('dog-details');
    const hawkDetails = document.getElementById('hawk-details');
    const foxDetails = document.getElementById('fox-details');
    const roleInfo = document.getElementById('role-info');
    
    // Fonction pour afficher les détails d'un rôle
    function showRoleDetails(roleElement) {
        // Cacher tous les détails
        dogDetails.classList.remove('active');
        hawkDetails.classList.remove('active');
        foxDetails.classList.remove('active');
        roleInfo.style.display = 'none';
        
        // Afficher les détails du rôle sélectionné
        roleElement.classList.add('active');
        
        // Ajouter une classe active au joueur sélectionné
        dogPlayer.classList.remove('selected');
        hawkPlayer.classList.remove('selected');
        foxPlayer.classList.remove('selected');
    }
    
    // Événements de clic pour chaque joueur
    dogPlayer.addEventListener('click', function() {
        showRoleDetails(dogDetails);
        dogPlayer.classList.add('selected');
    });
    
    hawkPlayer.addEventListener('click', function() {
        showRoleDetails(hawkDetails);
        hawkPlayer.classList.add('selected');
    });
    
    foxPlayer.addEventListener('click', function() {
        showRoleDetails(foxDetails);
        foxPlayer.classList.add('selected');
    });
    
    // Gestion du bouton de retour au guide
    const backButton = document.getElementById('back-to-guide');
    if (backButton) {
        backButton.addEventListener('click', function(e) {
            e.preventDefault();
            window.location.href = '../NHL25_Simple_Guide/index.html';
        });
    }
    
    // Ajouter des effets visuels pour les joueurs au survol
    const players = document.querySelectorAll('.player');
    players.forEach(player => {
        // Effet de pulsation au survol
        player.addEventListener('mouseenter', function() {
            gsap.to(this, {
                scale: 1.2,
                boxShadow: '0 0 15px rgba(255, 255, 255, 0.8)',
                duration: 0.3
            });
        });
        
        player.addEventListener('mouseleave', function() {
            gsap.to(this, {
                scale: 1,
                boxShadow: player.classList.contains('dog') ? '0 0 10px rgba(231, 76, 60, 0.7)' :
                           player.classList.contains('hawk') ? '0 0 10px rgba(52, 152, 219, 0.7)' :
                           player.classList.contains('fox') ? '0 0 10px rgba(46, 204, 113, 0.7)' :
                           player.classList.contains('defense') ? '0 0 10px rgba(155, 89, 182, 0.7)' :
                           '0 0 10px rgba(52, 73, 94, 0.7)',
                duration: 0.3
            });
        });
    });
    
    // Ajouter des effets aux boutons de scénario
    const scenarioButtons = document.querySelectorAll('.scenario-btn');
    scenarioButtons.forEach(button => {
        button.addEventListener('mouseenter', function() {
            if (!this.classList.contains('active')) {
                gsap.to(this, {
                    backgroundColor: '#2980b9',
                    scale: 1.05,
                    duration: 0.2
                });
            }
        });
        
        button.addEventListener('mouseleave', function() {
            if (!this.classList.contains('active')) {
                gsap.to(this, {
                    backgroundColor: '#2c3e50',
                    scale: 1,
                    duration: 0.2
                });
            }
        });
    });
    
    // Ajouter des effets aux boutons de contrôle
    const controlButtons = document.querySelectorAll('#play-btn, #pause-btn, #reset-btn');
    controlButtons.forEach(button => {
        button.addEventListener('mouseenter', function() {
            gsap.to(this, {
                backgroundColor: '#2980b9',
                scale: 1.05,
                duration: 0.2
            });
        });
        
        button.addEventListener('mouseleave', function() {
            gsap.to(this, {
                backgroundColor: '#2c3e50',
                scale: 1,
                duration: 0.2
            });
        });
    });
    
    // Ajouter des traînées visuelles pour les joueurs en mouvement
    function createTrail(player) {
        const trail = player.querySelector('.player-trail');
        if (trail) {
            // Créer une copie du joueur pour la traînée
            const trailEffect = document.createElement('div');
            trailEffect.className = 'player-trail-effect';
            trailEffect.style.width = '100%';
            trailEffect.style.height = '100%';
            trailEffect.style.borderRadius = '50%';
            trailEffect.style.position = 'absolute';
            trailEffect.style.backgroundColor = window.getComputedStyle(player).backgroundColor;
            trailEffect.style.opacity = '0.5';
            
            trail.appendChild(trailEffect);
            
            // Animer la traînée
            gsap.to(trailEffect, {
                opacity: 0,
                scale: 0.5,
                duration: 0.8,
                onComplete: function() {
                    if (trailEffect.parentNode) {
                        trailEffect.parentNode.removeChild(trailEffect);
                    }
                }
            });
        }
    }
    
    // Observer les changements de position des joueurs pour créer des traînées
    const dogObserver = new MutationObserver(function() {
        createTrail(dogPlayer);
    });
    
    const hawkObserver = new MutationObserver(function() {
        createTrail(hawkPlayer);
    });
    
    const foxObserver = new MutationObserver(function() {
        createTrail(foxPlayer);
    });
    
    // Configuration de l'observation
    const observerConfig = { attributes: true, attributeFilter: ['style'] };
    
    // Démarrer l'observation
    dogObserver.observe(dogPlayer, observerConfig);
    hawkObserver.observe(hawkPlayer, observerConfig);
    foxObserver.observe(foxPlayer, observerConfig);
    
    // Ajouter une classe CSS pour les joueurs sélectionnés
    const style = document.createElement('style');
    style.textContent = `
        .player.selected {
            transform: scale(1.2);
            z-index: 20;
        }
        .player.dog.selected {
            box-shadow: 0 0 20px rgba(231, 76, 60, 1);
        }
        .player.hawk.selected {
            box-shadow: 0 0 20px rgba(52, 152, 219, 1);
        }
        .player.fox.selected {
            box-shadow: 0 0 20px rgba(46, 204, 113, 1);
        }
        .player-trail-effect {
            pointer-events: none;
        }
    `;
    document.head.appendChild(style);
});
