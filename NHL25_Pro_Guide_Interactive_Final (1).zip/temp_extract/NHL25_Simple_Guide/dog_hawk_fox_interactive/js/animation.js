// Script pour l'animation du diagramme Dog-Hawk-Fox
// Utilise la bibliothèque GSAP pour des animations fluides

// Variables globales
let currentScenario = 'offensive';
let isPlaying = false;
let animationSpeed = 1;
let timeline;
let animations = {};

// Positions initiales des joueurs pour chaque scénario
const initialPositions = {
    offensive: {
        dog: { left: '60%', top: '30%' },
        hawk: { left: '70%', top: '70%' },
        fox: { left: '55%', top: '50%' },
        defense1: { left: '80%', top: '30%' },
        defense2: { left: '80%', top: '70%' },
        puck: { left: '60%', top: '30%' }
    },
    defensive: {
        dog: { left: '40%', top: '30%' },
        hawk: { left: '30%', top: '70%' },
        fox: { left: '45%', top: '50%' },
        defense1: { left: '20%', top: '30%' },
        defense2: { left: '20%', top: '70%' },
        puck: { left: '25%', top: '40%' }
    },
    transition: {
        dog: { left: '45%', top: '30%' },
        hawk: { left: '55%', top: '70%' },
        fox: { left: '50%', top: '50%' },
        defense1: { left: '40%', top: '20%' },
        defense2: { left: '40%', top: '80%' },
        puck: { left: '50%', top: '50%' }
    }
};

// Définition des animations pour chaque scénario
animations.offensive = (tl) => {
    // Animation du Dog (joueur agressif)
    tl.to('#dog-player', { 
        duration: 2, 
        left: '65%', 
        top: '25%',
        ease: 'power1.inOut'
    }, 0);
    
    // Animation du Hawk (joueur opportuniste)
    tl.to('#hawk-player', { 
        duration: 2, 
        left: '75%', 
        top: '65%',
        ease: 'power1.inOut'
    }, 0);
    
    // Animation du Fox (joueur positionnel)
    tl.to('#fox-player', { 
        duration: 2, 
        left: '60%', 
        top: '45%',
        ease: 'power1.inOut'
    }, 0);
    
    // Animation de la rondelle suivant le Dog
    tl.to('#puck', { 
        duration: 2, 
        left: '65%', 
        top: '25%',
        ease: 'power1.inOut'
    }, 0);
    
    // Deuxième séquence - Dog applique la pression
    tl.to('#dog-player', { 
        duration: 1.5, 
        left: '75%', 
        top: '20%',
        ease: 'power2.out'
    }, 2);
    
    tl.to('#puck', { 
        duration: 1.5, 
        left: '75%', 
        top: '20%',
        ease: 'power2.out'
    }, 2);
    
    // Fox se déplace pour soutenir
    tl.to('#fox-player', { 
        duration: 1.5, 
        left: '65%', 
        top: '35%',
        ease: 'power1.inOut'
    }, 2);
    
    // Hawk se positionne pour une opportunité
    tl.to('#hawk-player', { 
        duration: 1.5, 
        left: '70%', 
        top: '55%',
        ease: 'power1.inOut'
    }, 2);
    
    // Troisième séquence - Dog passe au Fox
    tl.to('#puck', { 
        duration: 0.5, 
        left: '65%', 
        top: '35%',
        ease: 'power4.out'
    }, 3.5);
    
    // Fox passe au Hawk pour un one-timer
    tl.to('#puck', { 
        duration: 0.5, 
        left: '70%', 
        top: '55%',
        ease: 'power4.out'
    }, 4);
    
    // Hawk tire
    tl.to('#puck', { 
        duration: 0.3, 
        left: '90%', 
        top: '50%',
        ease: 'power4.in'
    }, 4.5);
    
    // Retour aux positions initiales
    tl.to('#dog-player', { 
        duration: 1, 
        left: initialPositions.offensive.dog.left, 
        top: initialPositions.offensive.dog.top,
        ease: 'power1.inOut'
    }, 5);
    
    tl.to('#hawk-player', { 
        duration: 1, 
        left: initialPositions.offensive.hawk.left, 
        top: initialPositions.offensive.hawk.top,
        ease: 'power1.inOut'
    }, 5);
    
    tl.to('#fox-player', { 
        duration: 1, 
        left: initialPositions.offensive.fox.left, 
        top: initialPositions.offensive.fox.top,
        ease: 'power1.inOut'
    }, 5);
    
    tl.to('#puck', { 
        duration: 1, 
        left: initialPositions.offensive.puck.left, 
        top: initialPositions.offensive.puck.top,
        ease: 'power1.inOut'
    }, 5);
};

animations.defensive = (tl) => {
    // Animation du Dog (pression sur le porteur)
    tl.to('#dog-player', { 
        duration: 1.5, 
        left: '30%', 
        top: '40%',
        ease: 'power2.out'
    }, 0);
    
    // Animation du Fox (couverture du slot)
    tl.to('#fox-player', { 
        duration: 1.5, 
        left: '35%', 
        top: '50%',
        ease: 'power1.inOut'
    }, 0);
    
    // Animation du Hawk (couverture du point)
    tl.to('#hawk-player', { 
        duration: 1.5, 
        left: '40%', 
        top: '65%',
        ease: 'power1.inOut'
    }, 0);
    
    // Deuxième séquence - Dog force une erreur
    tl.to('#dog-player', { 
        duration: 1, 
        left: '25%', 
        top: '40%',
        ease: 'power3.out'
    }, 1.5);
    
    // Fox intercepte la passe
    tl.to('#puck', { 
        duration: 0.5, 
        left: '35%', 
        top: '50%',
        ease: 'power4.out'
    }, 2.5);
    
    // Troisième séquence - Transition rapide
    tl.to('#fox-player', { 
        duration: 1.5, 
        left: '50%', 
        top: '50%',
        ease: 'power2.inOut'
    }, 3);
    
    tl.to('#puck', { 
        duration: 1.5, 
        left: '50%', 
        top: '50%',
        ease: 'power2.inOut'
    }, 3);
    
    tl.to('#dog-player', { 
        duration: 1.5, 
        left: '55%', 
        top: '30%',
        ease: 'power2.inOut'
    }, 3);
    
    tl.to('#hawk-player', { 
        duration: 1.5, 
        left: '55%', 
        top: '70%',
        ease: 'power2.inOut'
    }, 3);
    
    // Retour aux positions initiales
    tl.to('#dog-player', { 
        duration: 1, 
        left: initialPositions.defensive.dog.left, 
        top: initialPositions.defensive.dog.top,
        ease: 'power1.inOut'
    }, 4.5);
    
    tl.to('#hawk-player', { 
        duration: 1, 
        left: initialPositions.defensive.hawk.left, 
        top: initialPositions.defensive.hawk.top,
        ease: 'power1.inOut'
    }, 4.5);
    
    tl.to('#fox-player', { 
        duration: 1, 
        left: initialPositions.defensive.fox.left, 
        top: initialPositions.defensive.fox.top,
        ease: 'power1.inOut'
    }, 4.5);
    
    tl.to('#puck', { 
        duration: 1, 
        left: initialPositions.defensive.puck.left, 
        top: initialPositions.defensive.puck.top,
        ease: 'power1.inOut'
    }, 4.5);
};

animations.transition = (tl) => {
    // Animation de transition rapide
    // Dog récupère la rondelle
    tl.to('#dog-player', { 
        duration: 1, 
        left: '45%', 
        top: '40%',
        ease: 'power2.out'
    }, 0);
    
    tl.to('#puck', { 
        duration: 1, 
        left: '45%', 
        top: '40%',
        ease: 'power2.out'
    }, 0);
    
    // Fox se déplace vers le centre
    tl.to('#fox-player', { 
        duration: 1, 
        left: '55%', 
        top: '45%',
        ease: 'power1.inOut'
    }, 0);
    
    // Hawk accélère en zone offensive
    tl.to('#hawk-player', { 
        duration: 1.5, 
        left: '70%', 
        top: '60%',
        ease: 'power3.in'
    }, 0);
    
    // Dog passe au Fox
    tl.to('#puck', { 
        duration: 0.3, 
        left: '55%', 
        top: '45%',
        ease: 'power4.out'
    }, 1);
    
    // Fox avance avec la rondelle
    tl.to('#fox-player', { 
        duration: 1.5, 
        left: '65%', 
        top: '50%',
        ease: 'power2.inOut'
    }, 1.3);
    
    tl.to('#puck', { 
        duration: 1.5, 
        left: '65%', 
        top: '50%',
        ease: 'power2.inOut'
    }, 1.3);
    
    // Dog se déplace en soutien
    tl.to('#dog-player', { 
        duration: 1.5, 
        left: '60%', 
        top: '30%',
        ease: 'power2.inOut'
    }, 1.3);
    
    // Fox passe au Hawk
    tl.to('#puck', { 
        duration: 0.3, 
        left: '70%', 
        top: '60%',
        ease: 'power4.out'
    }, 2.8);
    
    // Hawk tire
    tl.to('#puck', { 
        duration: 0.5, 
        left: '90%', 
        top: '50%',
        ease: 'power4.in'
    }, 3.1);
    
    // Retour aux positions initiales
    tl.to('#dog-player', { 
        duration: 1, 
        left: initialPositions.transition.dog.left, 
        top: initialPositions.transition.dog.top,
        ease: 'power1.inOut'
    }, 3.6);
    
    tl.to('#hawk-player', { 
        duration: 1, 
        left: initialPositions.transition.hawk.left, 
        top: initialPositions.transition.hawk.top,
        ease: 'power1.inOut'
    }, 3.6);
    
    tl.to('#fox-player', { 
        duration: 1, 
        left: initialPositions.transition.fox.left, 
        top: initialPositions.transition.fox.top,
        ease: 'power1.inOut'
    }, 3.6);
    
    tl.to('#puck', { 
        duration: 1, 
        left: initialPositions.transition.puck.left, 
        top: initialPositions.transition.puck.top,
        ease: 'power1.inOut'
    }, 3.6);
};

// Fonction pour initialiser les positions des joueurs
function initializePositions(scenario) {
    const positions = initialPositions[scenario];
    
    // Positionner les joueurs
    gsap.set('#dog-player', { left: positions.dog.left, top: positions.dog.top });
    gsap.set('#hawk-player', { left: positions.hawk.left, top: positions.hawk.top });
    gsap.set('#fox-player', { left: positions.fox.left, top: positions.fox.top });
    gsap.set('#defense-1', { left: positions.defense1.left, top: positions.defense1.top });
    gsap.set('#defense-2', { left: positions.defense2.left, top: positions.defense2.top });
    
    // Positionner la rondelle
    gsap.set('#puck', { left: positions.puck.left, top: positions.puck.top });
}

// Fonction pour créer et démarrer l'animation
function createAnimation(scenario) {
    // Arrêter l'animation précédente si elle existe
    if (timeline) {
        timeline.kill();
    }
    
    // Initialiser les positions
    initializePositions(scenario);
    
    // Créer une nouvelle timeline
    timeline = gsap.timeline({
        paused: true,
        repeat: -1,
        repeatDelay: 1,
        onRepeat: function() {
            // Réinitialiser les positions au début de chaque répétition
            initializePositions(scenario);
        }
    });
    
    // Ajouter les animations spécifiques au scénario
    if (animations[scenario]) {
        animations[scenario](timeline);
    }
    
    // Mettre à jour la vitesse
    timeline.timeScale(animationSpeed);
    
    return timeline;
}

// Fonction pour démarrer l'animation
function playAnimation() {
    if (!timeline || !isPlaying) {
        timeline = createAnimation(currentScenario);
        timeline.play();
        isPlaying = true;
    } else {
        timeline.play();
    }
}

// Fonction pour mettre en pause l'animation
function pauseAnimation() {
    if (timeline && isPlaying) {
        timeline.pause();
        isPlaying = false;
    }
}

// Fonction pour réinitialiser l'animation
function resetAnimation() {
    if (timeline) {
        timeline.kill();
    }
    
    timeline = createAnimation(currentScenario);
    
    if (isPlaying) {
        timeline.play();
    } else {
        timeline.pause(0);
    }
}

// Fonction pour changer de scénario
function changeScenario(scenario) {
    if (currentScenario !== scenario) {
        currentScenario = scenario;
        resetAnimation();
        
        // Mettre à jour l'interface utilisateur
        document.querySelectorAll('.scenario-btn').forEach(btn => {
            btn.classList.remove('active');
        });
        
        document.querySelectorAll(`.scenario-btn[data-scenario="${scenario}"]`).forEach(btn => {
            btn.classList.add('active');
        });
        
        document.querySelectorAll('.scenario-info').forEach(info => {
            info.classList.remove('active');
        });
        
        document.querySelector(`.${scenario}-info`).classList.add('active');
    }
}

// Fonction pour changer la vitesse de l'animation
function changeSpeed(speed) {
    animationSpeed = speed;
    if (timeline) {
        timeline.timeScale(speed);
    }
}

// Initialisation au chargement de la page
document.addEventListener('DOMContentLoaded', function() {
    // Initialiser les positions
    initializePositions(currentScenario);
    
    // Configurer les boutons de scénario
    document.querySelectorAll('.scenario-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            const scenario = this.getAttribute('data-scenario');
            changeScenario(scenario);
        });
    });
    
    // Configurer les boutons de lecture
    document.getElementById('play-btn').addEventListener('click', playAnimation);
    document.getElementById('pause-btn').addEventListener('click', pauseAnimation);
    document.getElementById('reset-btn').addEventListener('click', resetAnimation);
    
    // Configurer le slider de vitesse
    document.getElementById('speed-slider').addEventListener('input', function() {
        changeSpeed(parseFloat(this.value));
    });
    
    // Démarrer avec le scénario offensif
    changeScenario('offensive');
});
