// Script de gestion des langues pour le diagramme Dog-Hawk-Fox
// Gère le changement de langue et la persistance des préférences

// Dictionnaire de traduction
const translations = {
    fr: {
        // En-tête et navigation
        "title": "Diagramme Interactif Avancé Dog-Hawk-Fox",
        "subtitle": "Stratégie de positionnement professionnelle pour NHL 25",
        "back_to_guide": "Retour au Guide",
        
        // Scénarios
        "scenarios_title": "Scénarios Tactiques",
        "offensive": "Offensif",
        "defensive": "Défensif",
        "transition": "Transition",
        "powerplay": "Avantage Numérique",
        "penalty_kill": "Désavantage Numérique",
        
        // Contrôles
        "play": "Lecture",
        "pause": "Pause",
        "reset": "Réinitialiser",
        "speed": "Vitesse:",
        "display_options": "Options d'affichage:",
        "trails": "Trajectoires",
        "passing_lanes": "Lignes de passes",
        "coverage_zones": "Zones de couverture",
        
        // Onglets
        "roles_tab": "Rôles",
        "scenario_tab": "Scénario",
        "tips_tab": "Conseils Pro",
        
        // Rôles
        "roles_title": "Rôles des Joueurs",
        "roles_click_prompt": "Cliquez sur un joueur pour voir les détails de son rôle",
        
        // Dog
        "dog_title": "Dog (Chien) - Ailier Gauche",
        "dog_description": "Le <strong>Dog</strong> est le joueur le plus agressif du système. Son rôle principal est d'appliquer une pression constante sur le porteur de la rondelle et de forcer des erreurs. Il est le premier joueur en forecheck et doit être rapide, agressif et infatigable.",
        "dog_responsibilities": "Responsabilités:",
        "dog_resp_1": "Premier joueur en forecheck - applique une pression immédiate sur le porteur de rondelle",
        "dog_resp_2": "Récupération des rondelles dans les coins - utilise son agressivité pour gagner les batailles",
        "dog_resp_3": "Forcer les revirements - pousse les défenseurs adverses à faire des erreurs",
        "dog_resp_4": "Créer du chaos dans la zone offensive - perturbe la structure défensive adverse",
        "dog_resp_5": "Première ligne de défense - commence le backcheck quand la rondelle est perdue",
        "dog_attributes": "Attributs clés:",
        "dog_attr_1": "Vitesse",
        "dog_attr_2": "Agressivité",
        "dog_attr_3": "Endurance",
        "dog_attr_4": "Vérification",
        "dog_example": "Exemple en situation de jeu:",
        "dog_video": "Vidéo démonstrative du rôle Dog",
        "dog_watch": "Regarder la vidéo",
        
        // Hawk
        "hawk_title": "Hawk (Faucon) - Ailier Droit",
        "hawk_description": "Le <strong>Hawk</strong> est le joueur opportuniste du système. Son rôle est de se positionner stratégiquement pour exploiter les espaces créés par le Dog et le Fox. Il doit avoir une excellente vision du jeu et un bon tir pour capitaliser sur les occasions.",
        "hawk_responsibilities": "Responsabilités:",
        "hawk_resp_1": "Couverture haute en zone offensive - prêt à intercepter les dégagements ou à bloquer les sorties de zone",
        "hawk_resp_2": "Prêt pour les contre-attaques rapides - positionné pour recevoir des passes de transition",
        "hawk_resp_3": "Soutien du Dog quand nécessaire - offre une option de passe quand le Dog récupère la rondelle",
        "hawk_resp_4": "Se positionner pour des one-timers - trouve les espaces libres pour des tirs directs",
        "hawk_resp_5": "Couverture du point défensif - responsable de couvrir le défenseur adverse en zone défensive",
        "hawk_attributes": "Attributs clés:",
        "hawk_attr_1": "Tir",
        "hawk_attr_2": "Positionnement",
        "hawk_attr_3": "Vision",
        "hawk_attr_4": "Vitesse",
        "hawk_example": "Exemple en situation de jeu:",
        "hawk_video": "Vidéo démonstrative du rôle Hawk",
        "hawk_watch": "Regarder la vidéo",
        
        // Fox
        "fox_title": "Fox (Renard) - Centre",
        "fox_description": "Le <strong>Fox</strong> est le joueur intelligent et positionnel du système. Son rôle est de lire le jeu, d'anticiper les passes et de fournir un soutien défensif. C'est le cerveau tactique de la ligne, responsable de l'équilibre entre l'attaque et la défense.",
        "fox_responsibilities": "Responsabilités:",
        "fox_resp_1": "Soutien du Dog et couverture des lignes de passes centrales - positionné pour intercepter les passes adverses",
        "fox_resp_2": "Responsable du soutien défensif - premier attaquant à revenir en défense",
        "fox_resp_3": "Fournir des options de passes sécuritaires - toujours disponible comme option de passe",
        "fox_resp_4": "Lecture du jeu et anticipation - prévoit les mouvements adverses et s'adapte",
        "fox_resp_5": "Coordination des changements de rôle - dirige les transitions entre les rôles Dog/Hawk/Fox selon la situation",
        "fox_resp_6": "Couverture du slot défensif - protège la zone dangereuse devant le filet",
        "fox_attributes": "Attributs clés:",
        "fox_attr_1": "Intelligence de jeu",
        "fox_attr_2": "Passes",
        "fox_attr_3": "Défense",
        "fox_attr_4": "Mise en échec",
        "fox_example": "Exemple en situation de jeu:",
        "fox_video": "Vidéo démonstrative du rôle Fox",
        "fox_watch": "Regarder la vidéo",
        
        // Scénarios
        "offensive_title": "Scénario Offensif",
        "offensive_description": "Dans ce scénario, le système Dog-Hawk-Fox est utilisé pour maintenir la pression en zone offensive et créer des occasions de but. L'objectif est de forcer des revirements et de générer des tirs de qualité.",
        "offensive_sequence": "Déroulement du jeu:",
        "offensive_seq_1": "Le <strong>Dog</strong> applique une pression agressive sur le défenseur adverse en possession de la rondelle",
        "offensive_seq_2": "Le <strong>Fox</strong> se positionne pour couper les lignes de passes centrales",
        "offensive_seq_3": "Le <strong>Hawk</strong> reste haut pour bloquer la sortie de zone et être prêt pour un tir",
        "offensive_seq_4": "Le <strong>Dog</strong> force une passe précipitée que le <strong>Fox</strong> intercepte",
        "offensive_seq_5": "Le <strong>Fox</strong> passe au <strong>Hawk</strong> qui est bien positionné pour un tir direct",
        "offensive_stats": "Statistiques clés:",
        "offensive_stat_1": "Taux de récupération",
        "offensive_stat_2": "Tirs par séquence",
        "offensive_stat_3": "Temps moyen de possession",
        
        "defensive_title": "Scénario Défensif",
        "defensive_description": "Dans ce scénario, le système Dog-Hawk-Fox est adapté pour une couverture défensive efficace et pour contrer les attaques adverses. L'objectif est de limiter les occasions de but et de récupérer la possession.",
        "defensive_sequence": "Déroulement du jeu:",
        "defensive_seq_1": "Le <strong>Fox</strong> couvre le slot et soutient les défenseurs",
        "defensive_seq_2": "Le <strong>Dog</strong> applique une pression sur le porteur de rondelle",
        "defensive_seq_3": "Le <strong>Hawk</strong> couvre le point (défenseur adverse) et bloque les lignes de passes",
        "defensive_seq_4": "Le <strong>Dog</strong> force une passe risquée que le <strong>Fox</strong> intercepte",
        "defensive_seq_5": "Le <strong>Fox</strong> lance la contre-attaque en passant au <strong>Hawk</strong> qui est déjà en position offensive",
        "defensive_stats": "Statistiques clés:",
        "defensive_stat_1": "Taux d'interception",
        "defensive_stat_2": "Tirs adverses par séquence",
        "defensive_stat_3": "Temps moyen de transition",
        
        "transition_title": "Scénario de Transition",
        "transition_description": "Dans ce scénario, le système Dog-Hawk-Fox est utilisé pour passer rapidement de la défense à l'attaque et exploiter les opportunités de contre-attaque. L'objectif est de créer des surnombres offensifs.",
        "transition_sequence": "Déroulement du jeu:",
        "transition_seq_1": "Le <strong>Dog</strong> récupère la rondelle suite à une interception ou un revirement",
        "transition_seq_2": "Le <strong>Hawk</strong> accélère immédiatement en zone offensive pour créer une option de passe",
        "transition_seq_3": "Le <strong>Fox</strong> soutient le <strong>Dog</strong> et offre une option de passe sécuritaire",
        "transition_seq_4": "Le <strong>Dog</strong> passe au <strong>Fox</strong> qui avance rapidement en zone neutre",
        "transition_seq_5": "Le <strong>Fox</strong> passe au <strong>Hawk</strong> qui est en position idéale pour un tir ou une entrée de zone",
        "transition_stats": "Statistiques clés:",
        "transition_stat_1": "Taux de surnombres créés",
        "transition_stat_2": "Temps moyen de sortie de zone",
        "transition_stat_3": "Taux de conversion",
        
        "powerplay_title": "Scénario d'Avantage Numérique",
        "powerplay_description": "Dans ce scénario, le système Dog-Hawk-Fox est adapté pour maximiser l'efficacité en avantage numérique. L'objectif est de créer des lignes de passes claires et des opportunités de tir de qualité.",
        "powerplay_sequence": "Déroulement du jeu:",
        "powerplay_seq_1": "Le <strong>Fox</strong> contrôle la rondelle au centre de la zone offensive",
        "powerplay_seq_2": "Le <strong>Dog</strong> se positionne près du filet pour créer un écran ou récupérer les rebonds",
        "powerplay_seq_3": "Le <strong>Hawk</strong> se place dans le cercle de mise en jeu pour une option de one-timer",
        "powerplay_seq_4": "Les défenseurs restent hauts pour maintenir la pression et éviter les dégagements",
        "powerplay_seq_5": "Le <strong>Fox</strong> orchestre le mouvement de la rondelle pour déplacer la boîte défensive adverse",
        "powerplay_stats": "Statistiques clés:",
        "powerplay_stat_1": "Taux de conversion",
        "powerplay_stat_2": "Tirs par avantage",
        "powerplay_stat_3": "Temps en zone offensive",
        
        "penalty_kill_title": "Scénario de Désavantage Numérique",
        "penalty_kill_description": "Dans ce scénario, le système Dog-Hawk-Fox est adapté pour une défense efficace en infériorité numérique. L'objectif est de limiter les tirs de qualité et de dégager la rondelle quand possible.",
        "penalty_kill_sequence": "Déroulement du jeu:",
        "penalty_kill_seq_1": "Le <strong>Fox</strong> et le <strong>Dog</strong> forment un duo défensif en boîte ou en diamant",
        "penalty_kill_seq_2": "Le <strong>Fox</strong> couvre principalement le slot et les passes transversales",
        "penalty_kill_seq_3": "Le <strong>Dog</strong> applique une pression agressive sur le porteur de rondelle",
        "penalty_kill_seq_4": "Les défenseurs bloquent les lignes de tir et protègent le bas de la zone",
        "penalty_kill_seq_5": "Quand la rondelle est récupérée, le <strong>Dog</strong> devient l'option de dégagement principale",
        "penalty_kill_stats": "Statistiques clés:",
        "penalty_kill_stat_1": "Taux d'efficacité",
        "penalty_kill_stat_2": "Tirs de qualité concédés",
        "penalty_kill_stat_3": "Dégagements par désavantage",
        
        // Conseils Pro
        "tips_title": "Conseils Pro pour le Système Dog-Hawk-Fox",
        "tip_1_title": "Communication",
        "tip_1_content": "La communication est essentielle dans ce système. Annoncez clairement votre rôle (\"Dog\", \"Fox\" ou \"Hawk\") au début de chaque séquence offensive pour éviter la confusion et maintenir la structure.",
        "tip_2_title": "Rotation des rôles",
        "tip_2_content": "Les rôles peuvent et doivent changer dynamiquement pendant le jeu. Si vous êtes le premier joueur en zone offensive, vous devenez automatiquement le \"Dog\", quel que soit votre poste habituel.",
        "tip_3_title": "Gestion de l'énergie",
        "tip_3_content": "Le rôle de \"Dog\" est physiquement exigeant. Limitez vos séquences en tant que Dog à 15-20 secondes avant de passer à un rôle moins intense ou de changer de ligne.",
        "tip_4_title": "Pression ciblée",
        "tip_4_content": "En tant que \"Dog\", ciblez les défenseurs adverses les moins habiles avec la rondelle. Identifiez les joueurs qui ont tendance à paniquer sous pression et concentrez vos efforts sur eux.",
        "tip_5_title": "Vision périphérique",
        "tip_5_content": "En tant que \"Fox\", développez votre conscience spatiale et votre vision périphérique. Vous devez toujours savoir où sont vos coéquipiers et les adversaires, même sans les regarder directement.",
        "tip_6_title": "Préparation au tir",
        "tip_6_content": "En tant que \"Hawk\", soyez toujours prêt à tirer. Positionnez votre corps et votre bâton pour pouvoir décocher un tir rapidement, même si vous ne recevez pas immédiatement la rondelle.",
        "tip_7_title": "Adaptabilité",
        "tip_7_content": "Le système Dog-Hawk-Fox n'est pas rigide. Adaptez-le en fonction de l'adversaire, du score et du temps restant. Contre des équipes très offensives, vous pourriez avoir besoin que le Fox joue plus défensivement.",
        
        // Pied de page
        "footer_copyright": "NHL 25 Pro Guide &copy; 2025 - Créé pour améliorer votre jeu en EASHL 6v6",
        "footer_disclaimer": "Ce guide est une création non-officielle des fans pour les fans. NHL 25 et EASHL sont des marques déposées d'Electronic Arts Inc. Ce guide n'est pas affilié à EA Sports ou à la LNH. Toutes les informations sont basées sur l'expérience de jeu et l'analyse de la communauté."
    },
    en: {
        // Header and navigation
        "title": "Advanced Interactive Dog-Hawk-Fox Diagram",
        "subtitle": "Professional positioning strategy for NHL 25",
        "back_to_guide": "Back to Guide",
        
        // Scenarios
        "scenarios_title": "Tactical Scenarios",
        "offensive": "Offensive",
        "defensive": "Defensive",
        "transition": "Transition",
        "powerplay": "Power Play",
        "penalty_kill": "Penalty Kill",
        
        // Controls
        "play": "Play",
        "pause": "Pause",
        "reset": "Reset",
        "speed": "Speed:",
        "display_options": "Display options:",
        "trails": "Trails",
        "passing_lanes": "Passing lanes",
        "coverage_zones": "Coverage zones",
        
        // Tabs
        "roles_tab": "Roles",
        "scenario_tab": "Scenario",
        "tips_tab": "Pro Tips",
        
        // Roles
        "roles_title": "Player Roles",
        "roles_click_prompt": "Click on a player to see role details",
        
        // Dog
        "dog_title": "Dog - Left Wing",
        "dog_description": "The <strong>Dog</strong> is the most aggressive player in the system. Their main role is to apply constant pressure on the puck carrier and force errors. They are the first player on the forecheck and must be fast, aggressive, and tireless.",
        "dog_responsibilities": "Responsibilities:",
        "dog_resp_1": "First player on the forecheck - applies immediate pressure on the puck carrier",
        "dog_resp_2": "Puck retrieval in the corners - uses aggressiveness to win battles",
        "dog_resp_3": "Force turnovers - pushes opposing defensemen to make mistakes",
        "dog_resp_4": "Create chaos in the offensive zone - disrupts the opposing defensive structure",
        "dog_resp_5": "First line of defense - starts the backcheck when the puck is lost",
        "dog_attributes": "Key Attributes:",
        "dog_attr_1": "Speed",
        "dog_attr_2": "Aggressiveness",
        "dog_attr_3": "Endurance",
        "dog_attr_4": "Checking",
        "dog_example": "In-game example:",
        "dog_video": "Demonstration video of the Dog role",
        "dog_watch": "Watch video",
        
        // Hawk
        "hawk_title": "Hawk - Right Wing",
        "hawk_description": "The <strong>Hawk</strong> is the opportunistic player in the system. Their role is to position strategically to exploit spaces created by the Dog and Fox. They must have excellent vision and a good shot to capitalize on opportunities.",
        "hawk_responsibilities": "Responsibilities:",
        "hawk_resp_1": "High coverage in the offensive zone - ready to intercept clearances or block zone exits",
        "hawk_resp_2": "Ready for quick counterattacks - positioned to receive transition passes",
        "hawk_resp_3": "Support the Dog when necessary - provides a passing option when the Dog retrieves the puck",
        "hawk_resp_4": "Position for one-timers - finds open spaces for direct shots",
        "hawk_resp_5": "Coverage of the defensive point - responsible for covering the opposing defenseman in the defensive zone",
        "hawk_attributes": "Key Attributes:",
        "hawk_attr_1": "Shooting",
        "hawk_attr_2": "Positioning",
        "hawk_attr_3": "Vision",
        "hawk_attr_4": "Speed",
        "hawk_example": "In-game example:",
        "hawk_video": "Demonstration video of the Hawk role",
        "hawk_watch": "Watch video",
        
        // Fox
        "fox_title": "Fox - Center",
        "fox_description": "The <strong>Fox</strong> is the smart, positional player in the system. Their role is to read the play, anticipate passes, and provide defensive support. They are the tactical brain of the line, responsible for the balance between offense and defense.",
        "fox_responsibilities": "Responsibilities:",
        "fox_resp_1": "Support the Dog and cover central passing lanes - positioned to intercept opposing passes",
        "fox_resp_2": "Responsible for defensive support - first forward to come back on defense",
        "fox_resp_3": "Provide safe passing options - always available as a passing option",
        "fox_resp_4": "Read the play and anticipate - predicts opponent movements and adapts",
        "fox_resp_5": "Coordination of role changes - directs transitions between Dog/Hawk/Fox roles according to the situation",
        "fox_resp_6": "Coverage of the defensive slot - protects the dangerous area in front of the net",
        "fox_attributes": "Key Attributes:",
        "fox_attr_1": "Hockey IQ",
        "fox_attr_2": "Passing",
        "fox_attr_3": "Defense",
        "fox_attr_4": "Faceoffs",
        "fox_example": "In-game example:",
        "fox_video": "Demonstration video of the Fox role",
        "fox_watch": "Watch video",
        
        // Scenarios
        "offensive_title": "Offensive Scenario",
        "offensive_description": "In this scenario, the Dog-Hawk-Fox system is used to maintain pressure in the offensive zone and create scoring opportunities. The goal is to force turnovers and generate quality shots.",
        "offensive_sequence": "Play sequence:",
        "offensive_seq_1": "The <strong>Dog</strong> applies aggressive pressure on the opposing defenseman in possession of the puck",
        "offensive_seq_2": "The <strong>Fox</strong> positions to cut central passing lanes",
        "offensive_seq_3": "The <strong>Hawk</strong> stays high to block the zone exit and be ready for a shot",
        "offensive_seq_4": "The <strong>Dog</strong> forces a rushed pass that the <strong>Fox</strong> intercepts",
        "offensive_seq_5": "The <strong>Fox</strong> passes to the <strong>Hawk</strong> who is well positioned for a one-timer",
        "offensive_stats": "Key statistics:",
        "offensive_stat_1": "Recovery rate",
        "offensive_stat_2": "Shots per sequence",
        "offensive_stat_3": "Average possession time",
        
        "defensive_title": "Defensive Scenario",
        "defensive_description": "In this scenario, the Dog-Hawk-Fox system is adapted for effective defensive coverage and to counter opponent attacks. The goal is to limit scoring chances and regain possession.",
        "defensive_sequence": "Play sequence:",
        "defensive_seq_1": "The <strong>Fox</strong> covers the slot and supports the defensemen",
        "defensive_seq_2": "The <strong>Dog</strong> applies pressure on the puck carrier",
        "defensive_seq_3": "The <strong>Hawk</strong> covers the point (opposing defenseman) and blocks passing lanes",
        "defensive_seq_4": "The <strong>Dog</strong> forces a risky pass that the <strong>Fox</strong> intercepts",
        "defensive_seq_5": "The <strong>Fox</strong> launches the counterattack by passing to the <strong>Hawk</strong> who is already in offensive position",
        "defensive_stats": "Key statistics:",
        "defensive_stat_1": "Interception rate",
        "defensive_stat_2": "Opponent shots per sequence",
        "defensive_stat_3": "Average transition time",
        
        "transition_title": "Transition Scenario",
        "transition_description": "In this scenario, the Dog-Hawk-Fox system is used to quickly transition from defense to offense and exploit counterattack opportunities. The goal is to create offensive odd-man rushes.",
        "transition_sequence": "Play sequence:",
        "transition_seq_1": "The <strong>Dog</strong> recovers the puck following an interception or turnover",
        "transition_seq_2": "The <strong>Hawk</strong> immediately accelerates into the offensive zone to create a passing option",
        "transition_seq_3": "The <strong>Fox</strong> supports the <strong>Dog</strong> and offers a safe passing option",
        "transition_seq_4": "The <strong>Dog</strong> passes to the <strong>Fox</strong> who quickly advances into the neutral zone",
        "transition_seq_5": "The <strong>Fox</strong> passes to the <strong>Hawk</strong> who is in ideal position for a shot or zone entry",
        "transition_stats": "Key statistics:",
        "transition_stat_1": "Odd-man rushes created",
        "transition_stat_2": "Average zone exit time",
        "transition_stat_3": "Conversion rate",
        
        "powerplay_title": "Power Play Scenario",
        "powerplay_description": "In this scenario, the Dog-Hawk-Fox system is adapted to maximize power play efficiency. The goal is to create clear passing lanes and quality shooting opportunities.",
        "powerplay_sequence": "Play sequence:",
        "powerplay_seq_1": "The <strong>Fox</strong> controls the puck in the center of the offensive zone",
        "powerplay_seq_2": "The <strong>Dog</strong> positions near the net to create a screen or recover rebounds",
        "powerplay_seq_3": "The <strong>Hawk</strong> positions in the faceoff circle for a one-timer option",
        "powerplay_seq_4": "Defensemen stay high to maintain pressure and prevent clearances",
        "powerplay_seq_5": "The <strong>Fox</strong> orchestrates puck movement to shift the opposing defensive box",
        "powerplay_stats": "Key statistics:",
        "powerplay_stat_1": "Conversion rate",
        "powerplay_stat_2": "Shots per power play",
        "powerplay_stat_3": "Time in offensive zone",
        
        "penalty_kill_title": "Penalty Kill Scenario",
        "penalty_kill_description": "In this scenario, the Dog-Hawk-Fox system is adapted for effective defense while shorthanded. The goal is to limit quality shots and clear the puck when possible.",
        "penalty_kill_sequence": "Play sequence:",
        "penalty_kill_seq_1": "The <strong>Fox</strong> and <strong>Dog</strong> form a defensive duo in a box or diamond formation",
        "penalty_kill_seq_2": "The <strong>Fox</strong> primarily covers the slot and cross-ice passes",
        "penalty_kill_seq_3": "The <strong>Dog</strong> applies aggressive pressure on the puck carrier",
        "penalty_kill_seq_4": "Defensemen block shooting lanes and protect the low zone",
        "penalty_kill_seq_5": "When the puck is recovered, the <strong>Dog</strong> becomes the primary clearing option",
        "penalty_kill_stats": "Key statistics:",
        "penalty_kill_stat_1": "Kill efficiency",
        "penalty_kill_stat_2": "Quality shots allowed",
        "penalty_kill_stat_3": "Clears per penalty kill",
        
        // Pro Tips
        "tips_title": "Pro Tips for the Dog-Hawk-Fox System",
        "tip_1_title": "Communication",
        "tip_1_content": "Communication is essential in this system. Clearly announce your role (\"Dog\", \"Fox\", or \"Hawk\") at the beginning of each offensive sequence to avoid confusion and maintain structure.",
        "tip_2_title": "Role rotation",
        "tip_2_content": "Roles can and should change dynamically during play. If you're the first player into the offensive zone, you automatically become the \"Dog\", regardless of your usual position.",
        "tip_3_title": "Energy management",
        "tip_3_content": "The \"Dog\" role is physically demanding. Limit your sequences as the Dog to 15-20 seconds before switching to a less intense role or changing lines.",
        "tip_4_title": "Targeted pressure",
        "tip_4_content": "As the \"Dog\", target opposing defensemen who are less skilled with the puck. Identify players who tend to panic under pressure and focus your efforts on them.",
        "tip_5_title": "Peripheral vision",
        "tip_5_content": "As the \"Fox\", develop your spatial awareness and peripheral vision. You should always know where your teammates and opponents are, even without looking directly at them.",
        "tip_6_title": "Shot readiness",
        "tip_6_content": "As the \"Hawk\", always be ready to shoot. Position your body and stick so you can release a shot quickly, even if you don't immediately receive the puck.",
        "tip_7_title": "Adaptability",
        "tip_7_content": "The Dog-Hawk-Fox system is not rigid. Adapt it based on the opponent, score, and time remaining. Against highly offensive teams, you might need the Fox to play more defensively.",
        
        // Footer
        "footer_copyright": "NHL 25 Pro Guide &copy; 2025 - Created to improve your game in EASHL 6v6",
        "footer_disclaimer": "This guide is an unofficial fan creation for fans. NHL 25 and EASHL are registered trademarks of Electronic Arts Inc. This guide is not affiliated with EA Sports or the NHL. All information is based on gameplay experience and community analysis."
    }
};

// Fonction pour charger les traductions
function loadTranslations(lang) {
    const elements = document.querySelectorAll('[data-trans]');
    elements.forEach(element => {
        const key = element.getAttribute('data-trans');
        if (translations[lang] && translations[lang][key]) {
            element.innerHTML = translations[lang][key];
        }
    });
}

// Fonction pour initialiser le système de langue
function initLanguageSystem() {
    // Récupérer la langue sauvegardée ou utiliser le français par défaut
    let currentLang = localStorage.getItem('dhf-language') || 'fr';
    
    // Mettre à jour l'icône du bouton de langue
    const languageIcon = document.getElementById('language-icon');
    if (languageIcon) {
        languageIcon.textContent = currentLang === 'fr' ? '🇬🇧' : '🇫🇷';
    }
    
    // Charger les traductions initiales
    loadTranslations(currentLang);
    
    // Configurer le bouton de changement de langue
    const languageToggle = document.getElementById('language-toggle');
    if (languageToggle) {
        languageToggle.addEventListener('click', function() {
            // Basculer la langue
            currentLang = currentLang === 'fr' ? 'en' : 'fr';
            
            // Mettre à jour l'icône
            languageIcon.textContent = currentLang === 'fr' ? '🇬🇧' : '🇫🇷';
            
            // Mettre à jour le titre du bouton
            this.title = currentLang === 'fr' ? 'Switch to English' : 'Passer au français';
            
            // Charger les nouvelles traductions
            loadTranslations(currentLang);
            
            // Sauvegarder la préférence
            localStorage.setItem('dhf-language', currentLang);
            
            // Mettre à jour l'affichage des éléments avec data-lang
            updateLanguageDisplay(currentLang);
        });
    }
}

// Fonction pour mettre à jour l'affichage selon la langue
function updateLanguageDisplay(lang) {
    // Masquer tous les éléments de langue
    document.querySelectorAll('[data-lang]').forEach(el => {
        el.style.display = 'none';
    });
    
    // Afficher uniquement les éléments de la langue actuelle
    document.querySelectorAll(`[data-lang="${lang}"]`).forEach(el => {
        el.style.display = '';
    });
}

// Initialiser le système de langue au chargement de la page
document.addEventListener('DOMContentLoaded', initLanguageSystem);
