// Script d'interaction pour le diagramme Dog-Hawk-Fox
// Gère les interactions utilisateur et la fonctionnalité de changement de langue

// Variables globales pour la langue
let currentLanguage = 'fr'; // Langue par défaut: français

// Fonction pour changer la langue
function toggleLanguage() {
    // Basculer entre français et anglais
    currentLanguage = currentLanguage === 'fr' ? 'en' : 'fr';
    
    // Mettre à jour l'icône du bouton de langue
    const languageIcon = document.getElementById('language-icon');
    languageIcon.textContent = currentLanguage === 'fr' ? '🇬🇧' : '🇫🇷';
    
    // Mettre à jour le titre du bouton
    const languageToggle = document.getElementById('language-toggle');
    languageToggle.title = currentLanguage === 'fr' ? 'Switch to English' : 'Passer au français';
    
    // Mettre à jour tous les éléments avec attribut data-lang
    updateLanguageDisplay();
    
    // Sauvegarder la préférence de langue dans localStorage
    localStorage.setItem('dhf-language', currentLanguage);
}

// Fonction pour mettre à jour l'affichage selon la langue
function updateLanguageDisplay() {
    // Masquer tous les éléments de langue
    document.querySelectorAll('[data-lang]').forEach(el => {
        el.style.display = 'none';
    });
    
    // Afficher uniquement les éléments de la langue actuelle
    document.querySelectorAll(`[data-lang="${currentLanguage}"]`).forEach(el => {
        el.style.display = '';
    });
}

// Fonction pour vérifier l'exactitude des rôles Dog-Hawk-Fox
function verifyRoleAccuracy() {
    // Cette fonction vérifie que les descriptions et animations sont conformes
    // aux principes tactiques du système Dog-Hawk-Fox
    
    // Vérification des rôles principaux
    const dogRoleVerification = {
        primaryResponsibility: "Pression agressive sur le porteur de rondelle",
        positioning: "Premier joueur en forecheck",
        keyAttributes: ["Vitesse", "Agressivité", "Endurance"],
        commonMistakes: [
            "Poursuite excessive menant à des dépassements",
            "Pression insuffisante permettant des sorties de zone faciles",
            "Mauvais angle d'approche exposant les lignes de passe"
        ],
        correctExecution: [
            "Approche avec angle fermant les options de passe",
            "Utilisation du bâton dans les lignes de passe",
            "Pression constante sans surengagement"
        ]
    };
    
    const hawkRoleVerification = {
        primaryResponsibility: "Exploitation des espaces et opportunisme",
        positioning: "Position haute pour bloquer les sorties et prêt pour les tirs",
        keyAttributes: ["Tir", "Positionnement", "Vision"],
        commonMistakes: [
            "Positionnement trop bas réduisant les options offensives",
            "Anticipation excessive menant à des ruptures défensives",
            "Manque de soutien au Dog lors des batailles pour la rondelle"
        ],
        correctExecution: [
            "Maintien d'une position haute stratégique",
            "Préparation constante pour recevoir des passes ou tirer",
            "Lecture du jeu pour intercepter les dégagements"
        ]
    };
    
    const foxRoleVerification = {
        primaryResponsibility: "Soutien défensif et lecture du jeu",
        positioning: "Position centrale pour couper les lignes de passes et soutenir",
        keyAttributes: ["Intelligence de jeu", "Passes", "Défense"],
        commonMistakes: [
            "Positionnement trop offensif laissant des espaces centraux",
            "Manque de communication avec les ailiers",
            "Soutien défensif tardif lors des contre-attaques"
        ],
        correctExecution: [
            "Positionnement central pour couper les options de passe",
            "Communication constante pour coordonner la pression",
            "Premier attaquant à revenir en défense"
        ]
    };
    
    // Vérification des scénarios tactiques
    const scenarioVerification = {
        offensive: {
            primaryObjective: "Maintenir la pression et créer des occasions de but",
            keyElements: [
                "Dog applique une pression agressive",
                "Fox coupe les lignes de passes centrales",
                "Hawk reste haut pour bloquer la sortie et être prêt pour un tir"
            ],
            successMetrics: ["Taux de récupération", "Tirs par séquence", "Temps de possession"]
        },
        defensive: {
            primaryObjective: "Limiter les occasions et récupérer la possession",
            keyElements: [
                "Fox couvre le slot et soutient les défenseurs",
                "Dog applique une pression sur le porteur",
                "Hawk couvre le point et bloque les lignes de passes"
            ],
            successMetrics: ["Taux d'interception", "Tirs adverses limités", "Temps de transition"]
        },
        transition: {
            primaryObjective: "Passer rapidement de la défense à l'attaque",
            keyElements: [
                "Dog récupère la rondelle",
                "Hawk accélère en zone offensive",
                "Fox soutient et offre une option de passe sécuritaire"
            ],
            successMetrics: ["Taux de surnombres créés", "Temps de sortie de zone", "Taux de conversion"]
        }
    };
    
    // Vérification complète du système
    const systemVerification = {
        fundamentalPrinciples: [
            "Pression constante sur le porteur de rondelle",
            "Couverture des lignes de passes et des espaces dangereux",
            "Soutien mutuel entre les trois attaquants",
            "Adaptation dynamique des rôles selon la situation",
            "Communication constante entre les joueurs"
        ],
        commonSystemFailures: [
            "Manque de coordination entre les trois attaquants",
            "Surengagement menant à des surnombres adverses",
            "Espacement inadéquat réduisant les options offensives",
            "Transitions lentes entre les rôles",
            "Mauvaise lecture du jeu et anticipation"
        ],
        optimizationTips: [
            "Pratiquer les transitions de rôles en situation d'entraînement",
            "Développer un langage commun pour la communication en jeu",
            "Adapter le système selon les forces spécifiques des joueurs",
            "Analyser les vidéos pour identifier les points d'amélioration",
            "Maintenir une condition physique optimale pour l'exécution du système"
        ]
    };
    
    // Retourner les résultats de vérification
    return {
        roles: {
            dog: dogRoleVerification,
            hawk: hawkRoleVerification,
            fox: foxRoleVerification
        },
        scenarios: scenarioVerification,
        system: systemVerification,
        verificationStatus: "Completed",
        accuracyLevel: "High"
    };
}

// Initialisation au chargement de la page
document.addEventListener('DOMContentLoaded', function() {
    // Récupérer la préférence de langue si elle existe
    const savedLanguage = localStorage.getItem('dhf-language');
    if (savedLanguage) {
        currentLanguage = savedLanguage;
        
        // Mettre à jour l'icône du bouton de langue
        const languageIcon = document.getElementById('language-icon');
        if (languageIcon) {
            languageIcon.textContent = currentLanguage === 'fr' ? '🇬🇧' : '🇫🇷';
        }
        
        // Mettre à jour le titre du bouton
        const languageToggle = document.getElementById('language-toggle');
        if (languageToggle) {
            languageToggle.title = currentLanguage === 'fr' ? 'Switch to English' : 'Passer au français';
        }
    }
    
    // Appliquer la langue initiale
    updateLanguageDisplay();
    
    // Configurer le bouton de changement de langue
    const languageToggle = document.getElementById('language-toggle');
    if (languageToggle) {
        languageToggle.addEventListener('click', toggleLanguage);
    }
    
    // Vérifier l'exactitude des informations sur le système Dog-Hawk-Fox
    const verificationResults = verifyRoleAccuracy();
    console.log('Vérification du système Dog-Hawk-Fox:', verificationResults);
    
    // Ajouter des interactions supplémentaires pour améliorer l'expérience utilisateur
    
    // Effet de survol amélioré pour les joueurs
    document.querySelectorAll('.player').forEach(player => {
        player.addEventListener('mouseenter', function() {
            // Ajouter un effet de pulsation
            gsap.to(this, {
                scale: 1.2,
                boxShadow: '0 0 20px rgba(255, 255, 255, 0.5)',
                duration: 0.3
            });
        });
        
        player.addEventListener('mouseleave', function() {
            // Retirer l'effet de pulsation
            gsap.to(this, {
                scale: 1,
                boxShadow: '0 0 15px rgba(0, 0, 0, 0.3)',
                duration: 0.3
            });
        });
    });
    
    // Effet de survol pour les boutons de scénario
    document.querySelectorAll('.scenario-btn').forEach(btn => {
        btn.addEventListener('mouseenter', function() {
            if (!this.classList.contains('active')) {
                gsap.to(this, {
                    backgroundColor: 'rgba(52, 152, 219, 0.3)',
                    y: -2,
                    duration: 0.2
                });
            }
        });
        
        btn.addEventListener('mouseleave', function() {
            if (!this.classList.contains('active')) {
                gsap.to(this, {
                    backgroundColor: '',
                    y: 0,
                    duration: 0.2
                });
            }
        });
    });
    
    // Effet de clic pour les boutons de contrôle
    document.querySelectorAll('.control-btn').forEach(btn => {
        btn.addEventListener('mousedown', function() {
            gsap.to(this, {
                scale: 0.95,
                duration: 0.1
            });
        });
        
        btn.addEventListener('mouseup', function() {
            gsap.to(this, {
                scale: 1,
                duration: 0.1
            });
        });
        
        btn.addEventListener('mouseleave', function() {
            gsap.to(this, {
                scale: 1,
                duration: 0.1
            });
        });
    });
});
