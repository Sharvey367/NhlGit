// Scénarios de jeu supplémentaires pour le diagramme Dog-Hawk-Fox
// Définit des situations de jeu avancées et spécifiques

// Scénarios supplémentaires
const additionalScenarios = {
    // Scénario 1: Forecheck agressif en zone offensive
    aggressiveForecheck: {
        title: {
            fr: "Forecheck Agressif",
            en: "Aggressive Forecheck"
        },
        description: {
            fr: "Ce scénario illustre comment le système Dog-Hawk-Fox peut être utilisé pour appliquer une pression maximale lors du forecheck en zone offensive, particulièrement efficace contre des défenseurs moins habiles.",
            en: "This scenario illustrates how the Dog-Hawk-Fox system can be used to apply maximum pressure during offensive zone forechecking, particularly effective against less skilled defensemen."
        },
        keyPoints: {
            fr: [
                "Le <strong>Dog</strong> applique une pression immédiate et agressive sur le défenseur avec la rondelle",
                "Le <strong>Hawk</strong> coupe la première option de passe (généralement le long de la bande)",
                "Le <strong>Fox</strong> coupe la passe centrale et se prépare à intercepter",
                "Les défenseurs de l'équipe restent agressifs à la ligne bleue"
            ],
            en: [
                "The <strong>Dog</strong> applies immediate and aggressive pressure on the defenseman with the puck",
                "The <strong>Hawk</strong> cuts off the first passing option (usually along the boards)",
                "The <strong>Fox</strong> cuts off the central pass and prepares to intercept",
                "The team's defensemen stay aggressive at the blue line"
            ]
        },
        animation: {
            initialPositions: {
                dog: { left: '80%', top: '25%' },
                hawk: { left: '70%', top: '65%' },
                fox: { left: '65%', top: '45%' },
                defense1: { left: '60%', top: '30%' },
                defense2: { left: '60%', top: '70%' },
                opponent1: { left: '85%', top: '30%' },
                opponent2: { left: '85%', top: '70%' },
                opponent3: { left: '75%', top: '50%' },
                opponent4: { left: '90%', top: '40%' },
                opponent5: { left: '90%', top: '60%' },
                puck: { left: '85%', top: '30%' }
            },
            sequence: [
                // Étape 1: Dog applique la pression
                {
                    dog: { left: '83%', top: '28%', duration: 0.8 },
                    puck: { left: '83%', top: '28%', duration: 0.8 }
                },
                // Étape 2: Hawk coupe la première option de passe
                {
                    hawk: { left: '75%', top: '55%', duration: 1 }
                },
                // Étape 3: Fox se positionne pour l'interception
                {
                    fox: { left: '70%', top: '40%', duration: 1 }
                },
                // Étape 4: Défenseur adverse tente une passe risquée
                {
                    puck: { left: '75%', top: '45%', duration: 0.5 }
                },
                // Étape 5: Fox intercepte
                {
                    fox: { left: '75%', top: '45%', duration: 0.3 },
                    puck: { left: '75%', top: '45%', duration: 0.3 }
                },
                // Étape 6: Fox passe au Hawk pour un tir
                {
                    puck: { left: '75%', top: '55%', duration: 0.3 }
                }
            ]
        },
        tips: {
            fr: [
                "Identifiez le défenseur le plus faible et concentrez la pression du Dog sur lui",
                "Utilisez des signaux verbaux clairs pour coordonner la pression (ex: 'Pression! Pression!')",
                "Le Fox doit rester patient et ne pas surengager, servant de filet de sécurité",
                "Alternez entre pression totale et pression contrôlée pour déstabiliser l'adversaire"
            ],
            en: [
                "Identify the weakest defenseman and focus the Dog's pressure on them",
                "Use clear verbal signals to coordinate pressure (e.g., 'Pressure! Pressure!')",
                "The Fox must remain patient and not over-commit, serving as a safety net",
                "Alternate between full pressure and controlled pressure to destabilize the opponent"
            ]
        }
    },
    
    // Scénario 2: Contre-attaque rapide
    quickCounterattack: {
        title: {
            fr: "Contre-attaque Rapide",
            en: "Quick Counterattack"
        },
        description: {
            fr: "Ce scénario montre comment le système Dog-Hawk-Fox peut être utilisé pour lancer des contre-attaques rapides et efficaces après une récupération défensive, créant des occasions de marquer en surnombre.",
            en: "This scenario shows how the Dog-Hawk-Fox system can be used to launch quick and effective counterattacks after a defensive recovery, creating odd-man scoring opportunities."
        },
        keyPoints: {
            fr: [
                "Le <strong>Fox</strong> récupère la rondelle en zone défensive",
                "Le <strong>Hawk</strong> accélère immédiatement vers la zone offensive",
                "Le <strong>Dog</strong> crée une option de passe latérale",
                "Utilisation de passes rapides et directes pour traverser la zone neutre"
            ],
            en: [
                "The <strong>Fox</strong> recovers the puck in the defensive zone",
                "The <strong>Hawk</strong> immediately accelerates toward the offensive zone",
                "The <strong>Dog</strong> creates a lateral passing option",
                "Use of quick, direct passes to move through the neutral zone"
            ]
        },
        animation: {
            initialPositions: {
                dog: { left: '30%', top: '35%' },
                hawk: { left: '35%', top: '65%' },
                fox: { left: '25%', top: '50%' },
                defense1: { left: '15%', top: '35%' },
                defense2: { left: '15%', top: '65%' },
                opponent1: { left: '20%', top: '30%' },
                opponent2: { left: '20%', top: '70%' },
                opponent3: { left: '30%', top: '50%' },
                opponent4: { left: '40%', top: '40%' },
                opponent5: { left: '40%', top: '60%' },
                puck: { left: '25%', top: '50%' }
            },
            sequence: [
                // Étape 1: Fox récupère et commence la contre-attaque
                {
                    fox: { left: '35%', top: '50%', duration: 0.8 },
                    puck: { left: '35%', top: '50%', duration: 0.8 }
                },
                // Étape 2: Hawk accélère en zone offensive
                {
                    hawk: { left: '55%', top: '60%', duration: 1.2 }
                },
                // Étape 3: Dog crée une option de passe latérale
                {
                    dog: { left: '50%', top: '30%', duration: 1 }
                },
                // Étape 4: Fox passe au Dog
                {
                    puck: { left: '50%', top: '30%', duration: 0.4 }
                },
                // Étape 5: Dog avance et passe au Hawk
                {
                    dog: { left: '65%', top: '35%', duration: 0.8 },
                    puck: { left: '65%', top: '35%', duration: 0.8 }
                },
                // Étape 6: Dog passe au Hawk pour un tir
                {
                    puck: { left: '70%', top: '55%', duration: 0.3 }
                },
                // Étape 7: Hawk tire
                {
                    puck: { left: '95%', top: '50%', duration: 0.5 }
                }
            ]
        },
        tips: {
            fr: [
                "La vitesse est essentielle - les trois premiers pas doivent être explosifs",
                "Utilisez des passes directes et fermes, évitez les passes fantaisistes en contre-attaque",
                "Le Fox doit lire le jeu et choisir le bon moment pour la première passe",
                "Hawk et Dog doivent créer un écart entre eux pour étirer la défense adverse"
            ],
            en: [
                "Speed is essential - the first three steps must be explosive",
                "Use direct, firm passes; avoid fancy passes on the counterattack",
                "The Fox must read the play and choose the right moment for the first pass",
                "Hawk and Dog must create separation between them to stretch the opposing defense"
            ]
        }
    },
    
    // Scénario 3: Cycle offensif
    offensiveCycle: {
        title: {
            fr: "Cycle Offensif",
            en: "Offensive Cycle"
        },
        description: {
            fr: "Ce scénario illustre comment le système Dog-Hawk-Fox peut maintenir la possession en zone offensive grâce à un cycle efficace, créant des opportunités de tir de qualité tout en fatiguant la défense adverse.",
            en: "This scenario illustrates how the Dog-Hawk-Fox system can maintain possession in the offensive zone through effective cycling, creating quality shooting opportunities while tiring the opposing defense."
        },
        keyPoints: {
            fr: [
                "Le <strong>Dog</strong> établit la possession dans le coin",
                "Le <strong>Fox</strong> offre un soutien rapproché pour des passes courtes",
                "Le <strong>Hawk</strong> maintient une position haute pour une option de tir",
                "Rotation constante des positions pour désordonner la défense"
            ],
            en: [
                "The <strong>Dog</strong> establishes possession in the corner",
                "The <strong>Fox</strong> provides close support for short passes",
                "The <strong>Hawk</strong> maintains a high position for a shooting option",
                "Constant rotation of positions to disrupt the defense"
            ]
        },
        animation: {
            initialPositions: {
                dog: { left: '75%', top: '25%' },
                hawk: { left: '65%', top: '65%' },
                fox: { left: '60%', top: '45%' },
                defense1: { left: '80%', top: '30%' },
                defense2: { left: '80%', top: '70%' },
                opponent1: { left: '70%', top: '30%' },
                opponent2: { left: '70%', top: '70%' },
                opponent3: { left: '75%', top: '50%' },
                opponent4: { left: '85%', top: '40%' },
                opponent5: { left: '85%', top: '60%' },
                puck: { left: '75%', top: '25%' }
            },
            sequence: [
                // Étape 1: Dog établit la possession dans le coin
                {
                    dog: { left: '80%', top: '20%', duration: 0.8 },
                    puck: { left: '80%', top: '20%', duration: 0.8 }
                },
                // Étape 2: Fox offre un soutien rapproché
                {
                    fox: { left: '75%', top: '30%', duration: 0.8 }
                },
                // Étape 3: Dog passe au Fox
                {
                    puck: { left: '75%', top: '30%', duration: 0.3 }
                },
                // Étape 4: Dog se déplace vers le filet
                {
                    dog: { left: '85%', top: '40%', duration: 0.8 }
                },
                // Étape 5: Fox passe au Hawk
                {
                    fox: { left: '70%', top: '40%', duration: 0.8 },
                    puck: { left: '70%', top: '40%', duration: 0.8 }
                },
                // Étape 6: Fox passe au Hawk
                {
                    puck: { left: '65%', top: '65%', duration: 0.3 }
                },
                // Étape 7: Hawk passe au Dog près du filet
                {
                    puck: { left: '85%', top: '40%', duration: 0.3 }
                },
                // Étape 8: Dog tire
                {
                    puck: { left: '95%', top: '50%', duration: 0.4 }
                }
            ]
        },
        tips: {
            fr: [
                "Maintenez un triangle offensif avec une distance de 10-15 pieds entre les joueurs",
                "Utilisez la protection de rondelle (L2/LT) dans les coins pour gagner du temps",
                "Communiquez constamment pour indiquer votre position et disponibilité",
                "Variez entre cycle bas (dans les coins) et cycle haut (impliquant les défenseurs)"
            ],
            en: [
                "Maintain an offensive triangle with 10-15 feet between players",
                "Use puck protection (L2/LT) in the corners to buy time",
                "Communicate constantly to indicate your position and availability",
                "Vary between low cycling (in the corners) and high cycling (involving the defensemen)"
            ]
        }
    },
    
    // Scénario 4: Défense de zone
    zoneDefense: {
        title: {
            fr: "Défense de Zone",
            en: "Zone Defense"
        },
        description: {
            fr: "Ce scénario montre comment le système Dog-Hawk-Fox s'adapte pour une défense de zone efficace, protégeant les zones dangereuses tout en se préparant à la transition offensive.",
            en: "This scenario shows how the Dog-Hawk-Fox system adapts for effective zone defense, protecting dangerous areas while preparing for offensive transition."
        },
        keyPoints: {
            fr: [
                "Le <strong>Fox</strong> protège principalement le slot et soutient les défenseurs",
                "Le <strong>Dog</strong> et le <strong>Hawk</strong> couvrent les points (défenseurs adverses)",
                "Formation triangulaire défensive qui s'adapte au mouvement de la rondelle",
                "Préparation à la transition rapide dès la récupération"
            ],
            en: [
                "The <strong>Fox</strong> primarily protects the slot and supports the defensemen",
                "The <strong>Dog</strong> and <strong>Hawk</strong> cover the points (opposing defensemen)",
                "Defensive triangular formation that adapts to puck movement",
                "Preparation for quick transition upon recovery"
            ]
        },
        animation: {
            initialPositions: {
                dog: { left: '35%', top: '30%' },
                hawk: { left: '35%', top: '70%' },
                fox: { left: '25%', top: '50%' },
                defense1: { left: '15%', top: '35%' },
                defense2: { left: '15%', top: '65%' },
                opponent1: { left: '40%', top: '25%' },
                opponent2: { left: '40%', top: '75%' },
                opponent3: { left: '30%', top: '50%' },
                opponent4: { left: '20%', top: '30%' },
                opponent5: { left: '20%', top: '70%' },
                puck: { left: '30%', top: '50%' }
            },
            sequence: [
                // Étape 1: Fox protège le slot
                {
                    fox: { left: '20%', top: '50%', duration: 0.8 }
                },
                // Étape 2: Adversaire passe au point
                {
                    puck: { left: '40%', top: '25%', duration: 0.5 }
                },
                // Étape 3: Dog monte couvrir le point
                {
                    dog: { left: '38%', top: '28%', duration: 0.6 }
                },
                // Étape 4: Adversaire passe de l'autre côté
                {
                    puck: { left: '40%', top: '75%', duration: 0.6 }
                },
                // Étape 5: Hawk couvre l'autre point
                {
                    hawk: { left: '38%', top: '72%', duration: 0.6 }
                },
                // Étape 6: Adversaire tente une passe au slot
                {
                    puck: { left: '25%', top: '50%', duration: 0.4 }
                },
                // Étape 7: Fox intercepte
                {
                    fox: { left: '25%', top: '50%', duration: 0.2 },
                    puck: { left: '25%', top: '50%', duration: 0.2 }
                },
                // Étape 8: Fox lance la contre-attaque
                {
                    fox: { left: '40%', top: '50%', duration: 0.8 },
                    puck: { left: '40%', top: '50%', duration: 0.8 }
                }
            ]
        },
        tips: {
            fr: [
                "Priorisez la protection du slot et des lignes de passes dangereuses",
                "Maintenez une formation triangulaire qui se déplace comme une unité",
                "Communiquez les changements de couverture ('J'ai le point!', 'Slot!')",
                "Restez entre votre adversaire et votre filet, évitez de chasser la rondelle"
            ],
            en: [
                "Prioritize protecting the slot and dangerous passing lanes",
                "Maintain a triangular formation that moves as a unit",
                "Communicate coverage changes ('I've got point!', 'Slot!')",
                "Stay between your opponent and your net, avoid chasing the puck"
            ]
        }
    },
    
    // Scénario 5: Adaptation contre défense agressive
    adaptingToAggressiveDefense: {
        title: {
            fr: "Adaptation contre Défense Agressive",
            en: "Adapting to Aggressive Defense"
        },
        description: {
            fr: "Ce scénario montre comment le système Dog-Hawk-Fox peut s'adapter face à une défense très agressive, en utilisant des passes rapides et des changements de rythme pour exploiter les espaces.",
            en: "This scenario shows how the Dog-Hawk-Fox system can adapt against a very aggressive defense, using quick passes and changes of pace to exploit spaces."
        },
        keyPoints: {
            fr: [
                "Utilisation de passes courtes et rapides pour contrer la pression",
                "Le <strong>Fox</strong> devient plus offensif pour créer un surnombre",
                "Le <strong>Dog</strong> et le <strong>Hawk</strong> alternent entre soutien rapproché et positions éloignées",
                "Exploitation des espaces laissés par la défense agressive"
            ],
            en: [
                "Use of short, quick passes to counter pressure",
                "The <strong>Fox</strong> becomes more offensive to create numerical advantage",
                "The <strong>Dog</strong> and <strong>Hawk</strong> alternate between close support and distant positions",
                "Exploitation of spaces left by aggressive defense"
            ]
        },
        animation: {
            initialPositions: {
                dog: { left: '60%', top: '30%' },
                hawk: { left: '60%', top: '70%' },
                fox: { left: '50%', top: '50%' },
                defense1: { left: '40%', top: '30%' },
                defense2: { left: '40%', top: '70%' },
                opponent1: { left: '55%', top: '35%' },
                opponent2: { left: '55%', top: '65%' },
                opponent3: { left: '45%', top: '50%' },
                opponent4: { left: '35%', top: '40%' },
                opponent5: { left: '35%', top: '60%' },
                puck: { left: '50%', top: '50%' }
            },
            sequence: [
                // Étape 1: Fox avec la rondelle sous pression
                {
                    fox: { left: '52%', top: '48%', duration: 0.4 },
                    puck: { left: '52%', top: '48%', duration: 0.4 }
                },
                // Étape 2: Fox passe rapidement au Dog
                {
                    puck: { left: '60%', top: '30%', duration: 0.3 }
                },
                // Étape 3: Dog fait une passe rapide au Hawk
                {
                    puck: { left: '60%', top: '70%', duration: 0.3 }
                },
                // Étape 4: Fox se déplace en position offensive
                {
                    fox: { left: '65%', top: '50%', duration: 0.8 }
                },
                // Étape 5: Hawk passe au Fox
                {
                    puck: { left: '65%', top: '50%', duration: 0.3 }
                },
                // Étape 6: Dog se déplace vers le filet
                {
                    dog: { left: '75%', top: '40%', duration: 0.8 }
                },
                // Étape 7: Fox passe au Dog
                {
                    puck: { left: '75%', top: '40%', duration: 0.3 }
                },
                // Étape 8: Dog tire
                {
                    puck: { left: '95%', top: '50%', duration: 0.5 }
                }
            ]
        },
        tips: {
            fr: [
                "Utilisez des passes à une touche pour contrer la pression agressive",
                "Augmentez le tempo du jeu pour déstabiliser la défense",
                "Le Fox doit être plus offensif que d'habitude pour créer un surnombre",
                "Utilisez les feintes et les changements de direction pour créer de l'espace"
            ],
            en: [
                "Use one-touch passes to counter aggressive pressure",
                "Increase the tempo of play to destabilize the defense",
                "The Fox must be more offensive than usual to create numerical advantage",
                "Use feints and changes of direction to create space"
            ]
        }
    }
};

// Fonction pour initialiser les scénarios supplémentaires
function initializeAdditionalScenarios() {
    // Cette fonction sera appelée pour intégrer les scénarios supplémentaires
    // dans l'interface utilisateur et les animations
    
    // Ajouter les boutons de scénario à l'interface
    const scenarioSelector = document.querySelector('.scenario-selector');
    
    if (scenarioSelector) {
        // Ajouter un séparateur
        const separator = document.createElement('div');
        separator.className = 'scenario-separator';
        separator.innerHTML = '<span data-lang="fr">Scénarios Avancés</span><span data-lang="en">Advanced Scenarios</span>';
        scenarioSelector.appendChild(separator);
        
        // Ajouter les boutons pour chaque scénario supplémentaire
        Object.keys(additionalScenarios).forEach(scenarioKey => {
            const scenario = additionalScenarios[scenarioKey];
            
            // Créer le bouton en français
            const btnFr = document.createElement('button');
            btnFr.className = 'scenario-btn';
            btnFr.setAttribute('data-scenario', scenarioKey);
            btnFr.setAttribute('data-lang', 'fr');
            btnFr.textContent = scenario.title.fr;
            scenarioSelector.appendChild(btnFr);
            
            // Créer le bouton en anglais
            const btnEn = document.createElement('button');
            btnEn.className = 'scenario-btn';
            btnEn.setAttribute('data-scenario', scenarioKey);
            btnEn.setAttribute('data-lang', 'en');
            btnEn.textContent = scenario.title.en;
            scenarioSelector.appendChild(btnEn);
        });
    }
    
    // Ajouter les informations de scénario à l'onglet Scénario
    const scenarioTab = document.getElementById('scenario-tab');
    
    if (scenarioTab) {
        Object.keys(additionalScenarios).forEach(scenarioKey => {
            const scenario = additionalScenarios[scenarioKey];
            
            // Créer le conteneur d'information pour le scénario
            const infoContainer = document.createElement('div');
            infoContainer.className = `scenario-info ${scenarioKey}-info`;
            
            // Ajouter le contenu en français
            const titleFr = document.createElement('h3');
            titleFr.setAttribute('data-lang', 'fr');
            titleFr.textContent = scenario.title.fr;
            infoContainer.appendChild(titleFr);
            
            // Ajouter le contenu en anglais
            const titleEn = document.createElement('h3');
            titleEn.setAttribute('data-lang', 'en');
            titleEn.textContent = scenario.title.en;
            infoContainer.appendChild(titleEn);
            
            // Ajouter la description en français
            const descFr = document.createElement('p');
            descFr.setAttribute('data-lang', 'fr');
            descFr.textContent = scenario.description.fr;
            infoContainer.appendChild(descFr);
            
            // Ajouter la description en anglais
            const descEn = document.createElement('p');
            descEn.setAttribute('data-lang', 'en');
            descEn.textContent = scenario.description.en;
            infoContainer.appendChild(descEn);
            
            // Ajouter les points clés
            const keyPointsHeadingFr = document.createElement('h4');
            keyPointsHeadingFr.setAttribute('data-lang', 'fr');
            keyPointsHeadingFr.textContent = 'Points clés:';
            infoContainer.appendChild(keyPointsHeadingFr);
            
            const keyPointsHeadingEn = document.createElement('h4');
            keyPointsHeadingEn.setAttribute('data-lang', 'en');
            keyPointsHeadingEn.textContent = 'Key points:';
            infoContainer.appendChild(keyPointsHeadingEn);
            
            // Liste des points clés en français
            const keyPointsListFr = document.createElement('ul');
            keyPointsListFr.setAttribute('data-lang', 'fr');
            scenario.keyPoints.fr.forEach(point => {
                const li = document.createElement('li');
                li.innerHTML = point;
                keyPointsListFr.appendChild(li);
            });
            infoContainer.appendChild(keyPointsListFr);
            
            // Liste des points clés en anglais
            const keyPointsListEn = document.createElement('ul');
            keyPointsListEn.setAttribute('data-lang', 'en');
            scenario.keyPoints.en.forEach(point => {
                const li = document.createElement('li');
                li.innerHTML = point;
                keyPointsListEn.appendChild(li);
            });
            infoContainer.appendChild(keyPointsListEn);
            
            // Ajouter les conseils
            const tipsHeadingFr = document.createElement('h4');
            tipsHeadingFr.setAttribute('data-lang', 'fr');
            tipsHeadingFr.textContent = 'Conseils d\'exécution:';
            infoContainer.appendChild(tipsHeadingFr);
            
            const tipsHeadingEn = document.createElement('h4');
            tipsHeadingEn.setAttribute('data-lang', 'en');
            tipsHeadingEn.textContent = 'Execution tips:';
            infoContainer.appendChild(tipsHeadingEn);
            
            // Liste des conseils en français
            const tipsListFr = document.createElement('ul');
            tipsListFr.setAttribute('data-lang', 'fr');
            scenario.tips.fr.forEach(tip => {
                const li = document.createElement('li');
                li.textContent = tip;
                tipsListFr.appendChild(li);
            });
            infoContainer.appendChild(tipsListFr);
            
            // Liste des conseils en anglais
            const tipsListEn = document.createElement('ul');
            tipsListEn.setAttribute('data-lang', 'en');
            scenario.tips.en.forEach(tip => {
                const li = document.createElement('li');
                li.textContent = tip;
                tipsListEn.appendChild(li);
            });
            infoContainer.appendChild(tipsListEn);
            
            // Ajouter le conteneur au tab
            scenarioTab.appendChild(infoContainer);
        });
    }
    
    // Intégrer les animations des scénarios supplémentaires
    integrateAdditionalAnimations();
}

// Fonction pour intégrer les animations des scénarios supplémentaires
function integrateAdditionalAnimations() {
    // Cette fonction sera appelée pour intégrer les animations des scénarios supplémentaires
    // dans le système d'animation existant
    
    // Vérifier si l'objet global animations existe
    if (typeof window.animations === 'undefined') {
        console.error('L\'objet animations n\'est pas défini. Les scénarios supplémentaires ne peuvent pas être intégrés.');
        return;
    }
    
    // Ajouter les positions initiales pour chaque scénario
    if (typeof window.initialPositions === 'undefined') {
        window.initialPositions = {};
    }
    
    // Intégrer chaque scénario supplémentaire
    Object.keys(additionalScenarios).forEach(scenarioKey => {
        const scenario = additionalScenarios[scenarioKey];
        
        // Ajouter les positions initiales
        window.initialPositions[scenarioKey] = scenario.animation.initialPositions;
        
        // Créer la fonction d'animation pour ce scénario
        window.animations[scenarioKey] = (tl) => {
            // Mise à jour des zones de couverture (si la fonction existe)
            if (typeof updateCoverageZones === 'function') {
                updateCoverageZones(scenarioKey);
            }
            
            // Ajouter chaque étape de la séquence d'animation
            let timeOffset = 0;
            
            scenario.animation.sequence.forEach((step, index) => {
                // Animer chaque élément dans cette étape
                Object.keys(step).forEach(elementKey => {
                    const element = step[elementKey];
                    const duration = element.duration || 1;
                    
                    // Animer l'élément
                    tl.to(`#${elementKey}-player, #${elementKey}`.replace('puck-player', 'puck'), {
                        duration: duration,
                        left: element.left,
                        top: element.top,
                        ease: 'power2.inOut',
                        onUpdate: function() {
                            // Ajouter des effets de traînée pour les joueurs (si la fonction existe)
                            if (typeof createTrailEffect === 'function' && elementKey !== 'puck' && this.progress() % 0.2 < 0.01) {
                                createTrailEffect(elementKey);
                            }
                        }
                    }, timeOffset);
                    
                    // Mettre à jour les lignes de passes si nécessaire
                    if (elementKey === 'puck' && index > 0 && index < scenario.animation.sequence.length - 1) {
                        // Trouver le joueur qui a la rondelle avant et après cette étape
                        const prevStep = scenario.animation.sequence[index - 1];
                        const nextStep = scenario.animation.sequence[index + 1];
                        
                        // Si la rondelle passe d'un joueur à un autre, mettre à jour la ligne de passe
                        if (prevStep.puck && nextStep.puck) {
                            // Trouver le joueur source et destination
                            let sourcePlayer = null;
                            let destPlayer = null;
                            
                            // Parcourir tous les joueurs pour trouver la source
                            ['dog', 'hawk', 'fox'].forEach(player => {
                                if (prevStep[player] && prevStep.puck.left === prevStep[player].left && prevStep.puck.top === prevStep[player].top) {
                                    sourcePlayer = player;
                                }
                                if (step.puck.left === step[player]?.left && step.puck.top === step[player]?.top) {
                                    destPlayer = player;
                                }
                            });
                            
                            // Si on a identifié source et destination, mettre à jour la ligne de passe
                            if (sourcePlayer && destPlayer && typeof updatePassingLanes === 'function') {
                                tl.call(() => {
                                    updatePassingLanes(sourcePlayer, destPlayer);
                                }, null, timeOffset + duration * 0.5);
                            }
                        }
                    }
                });
                
                // Mettre à jour le décalage temporel pour la prochaine étape
                timeOffset += Object.values(step)[0].duration || 1;
            });
            
            // Ajouter un tir à la fin si la dernière étape implique un mouvement de la rondelle vers le filet
            const lastStep = scenario.animation.sequence[scenario.animation.sequence.length - 1];
            if (lastStep.puck && lastStep.puck.left > '90%') {
                // Trouver le joueur qui tire
                let shootingPlayer = null;
                const prevStep = scenario.animation.sequence[scenario.animation.sequence.length - 2];
                
                ['dog', 'hawk', 'fox'].forEach(player => {
                    if (prevStep[player] && prevStep.puck.left === prevStep[player].left && prevStep.puck.top === prevStep[player].top) {
                        shootingPlayer = player;
                    }
                });
                
                if (shootingPlayer && typeof createShotTrajectory === 'function') {
                    tl.call(() => {
                        createShotTrajectory(shootingPlayer, '.goal-right');
                    }, null, timeOffset - lastStep.puck.duration);
                }
            }
            
            // Retour aux positions initiales
            tl.to('#dog-player', {
                duration: 1,
                left: scenario.animation.initialPositions.dog.left,
                top: scenario.animation.initialPositions.dog.top,
                ease: 'power1.inOut'
            }, timeOffset + 1);
            
            tl.to('#hawk-player', {
                duration: 1,
                left: scenario.animation.initialPositions.hawk.left,
                top: scenario.animation.initialPositions.hawk.top,
                ease: 'power1.inOut'
            }, timeOffset + 1);
            
            tl.to('#fox-player', {
                duration: 1,
                left: scenario.animation.initialPositions.fox.left,
                top: scenario.animation.initialPositions.fox.top,
                ease: 'power1.inOut'
            }, timeOffset + 1);
            
            tl.to('#puck', {
                duration: 1,
                left: scenario.animation.initialPositions.puck.left,
                top: scenario.animation.initialPositions.puck.top,
                ease: 'power1.inOut'
            }, timeOffset + 1);
            
            // Mise à jour de la timeline
            tl.to('#timeline-progress', {
                width: '100%',
                duration: timeOffset + 2,
                ease: 'none'
            }, 0);
        };
    });
    
    // Ajouter les gestionnaires d'événements pour les nouveaux boutons de scénario
    document.querySelectorAll('.scenario-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            const scenario = this.getAttribute('data-scenario');
            if (typeof changeScenario === 'function') {
                changeScenario(scenario);
            }
        });
    });
}

// Initialiser les scénarios supplémentaires au chargement de la page
document.addEventListener('DOMContentLoaded', function() {
    // Initialiser les scénarios supplémentaires
    initializeAdditionalScenarios();
    
    // Ajouter des styles CSS pour les nouveaux éléments
    const style = document.createElement('style');
    style.textContent = `
        .scenario-separator {
            width: 100%;
            text-align: center;
            margin: 15px 0 10px;
            padding-top: 10px;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
            color: #3498db;
            font-weight: 600;
        }
    `;
    document.head.appendChild(style);
});
