// Script d'animation amélioré pour le diagramme Dog-Hawk-Fox
// Utilise GSAP et MotionPathPlugin pour des animations plus fluides et réalistes

// Variables globales
let currentScenario = 'offensive';
let isPlaying = false;
let animationSpeed = 1;
let timeline;
let animations = {};
let showTrails = true;
let showPassingLanes = true;
let showCoverageZones = true;

// Positions initiales des joueurs pour chaque scénario
const initialPositions = {
    offensive: {
        dog: { left: '60%', top: '30%' },
        hawk: { left: '70%', top: '70%' },
        fox: { left: '55%', top: '50%' },
        defense1: { left: '80%', top: '30%' },
        defense2: { left: '80%', top: '70%' },
        opponent1: { left: '85%', top: '25%' },
        opponent2: { left: '85%', top: '50%' },
        opponent3: { left: '85%', top: '75%' },
        opponent4: { left: '75%', top: '20%' },
        opponent5: { left: '75%', top: '80%' },
        puck: { left: '60%', top: '30%' }
    },
    defensive: {
        dog: { left: '40%', top: '30%' },
        hawk: { left: '30%', top: '70%' },
        fox: { left: '45%', top: '50%' },
        defense1: { left: '20%', top: '30%' },
        defense2: { left: '20%', top: '70%' },
        opponent1: { left: '15%', top: '25%' },
        opponent2: { left: '15%', top: '50%' },
        opponent3: { left: '15%', top: '75%' },
        opponent4: { left: '25%', top: '20%' },
        opponent5: { left: '25%', top: '80%' },
        puck: { left: '25%', top: '40%' }
    },
    transition: {
        dog: { left: '45%', top: '30%' },
        hawk: { left: '55%', top: '70%' },
        fox: { left: '50%', top: '50%' },
        defense1: { left: '40%', top: '20%' },
        defense2: { left: '40%', top: '80%' },
        opponent1: { left: '60%', top: '25%' },
        opponent2: { left: '60%', top: '50%' },
        opponent3: { left: '60%', top: '75%' },
        opponent4: { left: '70%', top: '30%' },
        opponent5: { left: '70%', top: '70%' },
        puck: { left: '50%', top: '50%' }
    },
    powerplay: {
        dog: { left: '75%', top: '30%' },
        hawk: { left: '75%', top: '70%' },
        fox: { left: '65%', top: '50%' },
        defense1: { left: '85%', top: '40%' },
        defense2: { left: '85%', top: '60%' },
        opponent1: { left: '90%', top: '30%' },
        opponent2: { left: '90%', top: '50%' },
        opponent3: { left: '90%', top: '70%' },
        opponent4: { left: '80%', top: '45%' },
        puck: { left: '65%', top: '50%' }
    },
    'penalty-kill': {
        dog: { left: '25%', top: '40%' },
        fox: { left: '35%', top: '50%' },
        defense1: { left: '15%', top: '40%' },
        defense2: { left: '15%', top: '60%' },
        opponent1: { left: '10%', top: '30%' },
        opponent2: { left: '10%', top: '50%' },
        opponent3: { left: '10%', top: '70%' },
        opponent4: { left: '20%', top: '25%' },
        opponent5: { left: '20%', top: '75%' },
        puck: { left: '10%', top: '50%' }
    }
};

// Définition des zones de couverture pour chaque rôle
const coverageZones = {
    offensive: {
        dog: { left: '65%', top: '30%', width: '120px', height: '120px' },
        hawk: { left: '70%', top: '65%', width: '120px', height: '120px' },
        fox: { left: '60%', top: '50%', width: '150px', height: '150px' }
    },
    defensive: {
        dog: { left: '35%', top: '35%', width: '100px', height: '100px' },
        hawk: { left: '35%', top: '65%', width: '100px', height: '100px' },
        fox: { left: '40%', top: '50%', width: '150px', height: '150px' }
    },
    transition: {
        dog: { left: '45%', top: '35%', width: '100px', height: '100px' },
        hawk: { left: '60%', top: '65%', width: '100px', height: '100px' },
        fox: { left: '50%', top: '50%', width: '150px', height: '150px' }
    },
    powerplay: {
        dog: { left: '75%', top: '30%', width: '100px', height: '100px' },
        hawk: { left: '75%', top: '70%', width: '100px', height: '100px' },
        fox: { left: '65%', top: '50%', width: '150px', height: '150px' }
    },
    'penalty-kill': {
        dog: { left: '25%', top: '40%', width: '80px', height: '80px' },
        fox: { left: '35%', top: '50%', width: '120px', height: '120px' }
    }
};

// Fonction pour mettre à jour les zones de couverture
function updateCoverageZones(scenario) {
    if (!showCoverageZones) {
        gsap.set('.coverage-zone', { opacity: 0 });
        return;
    }
    
    const zones = coverageZones[scenario];
    
    // Mettre à jour la zone du Dog
    if (zones.dog) {
        gsap.to('#dog-zone', {
            left: zones.dog.left,
            top: zones.dog.top,
            width: zones.dog.width,
            height: zones.dog.height,
            opacity: 0.15,
            duration: 0.5
        });
    } else {
        gsap.to('#dog-zone', { opacity: 0, duration: 0.5 });
    }
    
    // Mettre à jour la zone du Hawk
    if (zones.hawk) {
        gsap.to('#hawk-zone', {
            left: zones.hawk.left,
            top: zones.hawk.top,
            width: zones.hawk.width,
            height: zones.hawk.height,
            opacity: 0.15,
            duration: 0.5
        });
    } else {
        gsap.to('#hawk-zone', { opacity: 0, duration: 0.5 });
    }
    
    // Mettre à jour la zone du Fox
    if (zones.fox) {
        gsap.to('#fox-zone', {
            left: zones.fox.left,
            top: zones.fox.top,
            width: zones.fox.width,
            height: zones.fox.height,
            opacity: 0.15,
            duration: 0.5
        });
    } else {
        gsap.to('#fox-zone', { opacity: 0, duration: 0.5 });
    }
}

// Fonction pour mettre à jour les lignes de passes
function updatePassingLanes(from, to, visible = true) {
    if (!showPassingLanes || !visible) {
        return;
    }
    
    const fromElement = document.getElementById(`${from}-player`);
    const toElement = document.getElementById(`${to}-player`);
    const laneElement = document.getElementById(`${from}-${to}-lane`);
    
    if (!fromElement || !toElement || !laneElement) {
        return;
    }
    
    const fromRect = fromElement.getBoundingClientRect();
    const toRect = toElement.getBoundingClientRect();
    const rinkRect = document.querySelector('.rink').getBoundingClientRect();
    
    // Calculer les positions relatives à la patinoire
    const fromX = fromRect.left + fromRect.width / 2 - rinkRect.left;
    const fromY = fromRect.top + fromRect.height / 2 - rinkRect.top;
    const toX = toRect.left + toRect.width / 2 - rinkRect.left;
    const toY = toRect.top + toRect.height / 2 - rinkRect.top;
    
    // Calculer la longueur et l'angle de la ligne
    const length = Math.sqrt(Math.pow(toX - fromX, 2) + Math.pow(toY - fromY, 2));
    const angle = Math.atan2(toY - fromY, toX - fromX) * 180 / Math.PI;
    
    // Mettre à jour la ligne de passe
    gsap.to(laneElement, {
        left: `${fromX}px`,
        top: `${fromY}px`,
        width: `${length}px`,
        rotation: angle,
        opacity: 0.6,
        duration: 0.3
    });
}

// Fonction pour créer une trajectoire de tir
function createShotTrajectory(from, to) {
    const fromElement = document.getElementById(`${from}-player`);
    const toElement = document.querySelector(to);
    const trajectoryElement = document.getElementById('shot-trajectory');
    
    if (!fromElement || !toElement || !trajectoryElement) {
        return;
    }
    
    const fromRect = fromElement.getBoundingClientRect();
    const toRect = toElement.getBoundingClientRect();
    const rinkRect = document.querySelector('.rink').getBoundingClientRect();
    
    // Calculer les positions relatives à la patinoire
    const fromX = fromRect.left + fromRect.width / 2 - rinkRect.left;
    const fromY = fromRect.top + fromRect.height / 2 - rinkRect.top;
    const toX = toRect.left + toRect.width / 2 - rinkRect.left;
    const toY = toRect.top + toRect.height / 2 - rinkRect.top;
    
    // Calculer la longueur et l'angle de la trajectoire
    const length = Math.sqrt(Math.pow(toX - fromX, 2) + Math.pow(toY - fromY, 2));
    const angle = Math.atan2(toY - fromY, toX - fromX) * 180 / Math.PI;
    
    // Animer la trajectoire de tir
    gsap.set(trajectoryElement, {
        left: `${fromX}px`,
        top: `${fromY}px`,
        width: 0,
        rotation: angle,
        opacity: 0
    });
    
    gsap.to(trajectoryElement, {
        width: `${length}px`,
        opacity: 0.8,
        duration: 0.5,
        onComplete: function() {
            gsap.to(trajectoryElement, {
                opacity: 0,
                duration: 0.3,
                delay: 0.2
            });
        }
    });
}

// Fonction pour créer un effet de traînée
function createTrailEffect(player) {
    if (!showTrails) {
        return;
    }
    
    const playerElement = document.getElementById(`${player}-player`);
    if (!playerElement) {
        return;
    }
    
    const trail = playerElement.querySelector('.player-trail');
    if (!trail) {
        return;
    }
    
    // Créer un élément de traînée
    const trailEffect = document.createElement('div');
    trailEffect.className = 'trail-effect';
    trailEffect.style.width = '100%';
    trailEffect.style.height = '100%';
    trailEffect.style.borderRadius = '50%';
    trailEffect.style.position = 'absolute';
    trailEffect.style.backgroundColor = window.getComputedStyle(playerElement).backgroundColor;
    trailEffect.style.opacity = '0.5';
    
    trail.appendChild(trailEffect);
    
    // Animer la traînée
    gsap.to(trailEffect, {
        opacity: 0,
        scale: 0.5,
        duration: 0.8,
        onComplete: function() {
            if (trailEffect.parentNode) {
                trailEffect.parentNode.removeChild(trailEffect);
            }
        }
    });
}

// Définition des animations pour chaque scénario
animations.offensive = (tl) => {
    // Mise à jour des zones de couverture
    updateCoverageZones('offensive');
    
    // Séquence 1: Dog applique la pression
    tl.to('#dog-player', { 
        duration: 1.5, 
        left: '70%', 
        top: '25%',
        ease: 'power2.inOut',
        onUpdate: function() {
            if (this.progress() % 0.1 < 0.01) {
                createTrailEffect('dog');
            }
        }
    }, 0);
    
    tl.to('#puck', { 
        duration: 1.5, 
        left: '70%', 
        top: '25%',
        ease: 'power2.inOut'
    }, 0);
    
    // Fox se positionne pour le soutien
    tl.to('#fox-player', { 
        duration: 1.5, 
        left: '60%', 
        top: '40%',
        ease: 'power1.inOut',
        onUpdate: function() {
            if (this.progress() % 0.2 < 0.01) {
                createTrailEffect('fox');
            }
        }
    }, 0);
    
    // Hawk reste haut pour bloquer la sortie
    tl.to('#hawk-player', { 
        duration: 1.5, 
        left: '65%', 
        top: '65%',
        ease: 'power1.inOut',
        onUpdate: function() {
            if (this.progress() % 0.2 < 0.01) {
                createTrailEffect('hawk');
            }
        }
    }, 0);
    
    // Séquence 2: Dog force une passe que Fox intercepte
    tl.to('#opponent1', { 
        duration: 0.8, 
        left: '75%', 
        top: '30%',
        ease: 'power1.inOut'
    }, 1.5);
    
    tl.to('#puck', { 
        duration: 0.3, 
        left: '65%', 
        top: '35%',
        ease: 'power4.out'
    }, 2.3);
    
    tl.call(() => {
        updatePassingLanes('fox', 'hawk');
    }, null, 2.6);
    
    // Fox intercepte et passe au Hawk
    tl.to('#puck', { 
        duration: 0.5, 
        left: '65%', 
        top: '65%',
        ease: 'power2.inOut'
    }, 2.6);
    
    // Hawk tire
    tl.call(() => {
        createShotTrajectory('hawk', '.goal-right');
    }, null, 3.1);
    
    tl.to('#puck', { 
        duration: 0.5, 
        left: '95%', 
        top: '50%',
        ease: 'power3.in'
    }, 3.1);
    
    // Séquence 3: Nouvelle configuration offensive
    tl.to('#dog-player', { 
        duration: 1, 
        left: '75%', 
        top: '35%',
        ease: 'power1.inOut',
        onUpdate: function() {
            if (this.progress() % 0.2 < 0.01) {
                createTrailEffect('dog');
            }
        }
    }, 4);
    
    tl.to('#fox-player', { 
        duration: 1, 
        left: '65%', 
        top: '50%',
        ease: 'power1.inOut',
        onUpdate: function() {
            if (this.progress() % 0.2 < 0.01) {
                createTrailEffect('fox');
            }
        }
    }, 4);
    
    tl.to('#hawk-player', { 
        duration: 1, 
        left: '75%', 
        top: '65%',
        ease: 'power1.inOut',
        onUpdate: function() {
            if (this.progress() % 0.2 < 0.01) {
                createTrailEffect('hawk');
            }
        }
    }, 4);
    
    tl.to('#puck', { 
        duration: 0.5, 
        left: '65%', 
        top: '50%',
        ease: 'power1.inOut'
    }, 5);
    
    // Fox distribue le jeu
    tl.call(() => {
        updatePassingLanes('fox', 'dog');
    }, null, 5.5);
    
    tl.to('#puck', { 
        duration: 0.3, 
        left: '75%', 
        top: '35%',
        ease: 'power2.out'
    }, 5.5);
    
    // Dog passe à Hawk pour un one-timer
    tl.call(() => {
        updatePassingLanes('dog', 'hawk');
    }, null, 6);
    
    tl.to('#puck', { 
        duration: 0.3, 
        left: '75%', 
        top: '65%',
        ease: 'power2.out'
    }, 6);
    
    // Hawk tire à nouveau
    tl.call(() => {
        createShotTrajectory('hawk', '.goal-right');
    }, null, 6.3);
    
    tl.to('#puck', { 
        duration: 0.5, 
        left: '95%', 
        top: '50%',
        ease: 'power3.in'
    }, 6.3);
    
    // Retour aux positions initiales
    tl.to('#dog-player', { 
        duration: 1, 
        left: initialPositions.offensive.dog.left, 
        top: initialPositions.offensive.dog.top,
        ease: 'power1.inOut'
    }, 7);
    
    tl.to('#hawk-player', { 
        duration: 1, 
        left: initialPositions.offensive.hawk.left, 
        top: initialPositions.offensive.hawk.top,
        ease: 'power1.inOut'
    }, 7);
    
    tl.to('#fox-player', { 
        duration: 1, 
        left: initialPositions.offensive.fox.left, 
        top: initialPositions.offensive.fox.top,
        ease: 'power1.inOut'
    }, 7);
    
    tl.to('#puck', { 
        duration: 1, 
        left: initialPositions.offensive.puck.left, 
        top: initialPositions.offensive.puck.top,
        ease: 'power1.inOut'
    }, 7);
    
    // Mise à jour de la timeline
    tl.to('#timeline-progress', {
        width: '100%',
        duration: 8,
        ease: 'none'
    }, 0);
};

animations.defensive = (tl) => {
    // Mise à jour des zones de couverture
    updateCoverageZones('defensive');
    
    // Séquence 1: Fox couvre le slot, Dog applique la pression
    tl.to('#fox-player', { 
        duration: 1, 
        left: '35%', 
        top: '50%',
        ease: 'power1.inOut',
        onUpdate: function() {
            if (this.progress() % 0.2 < 0.01) {
                createTrailEffect('fox');
            }
        }
    }, 0);
    
    tl.to('#dog-player', { 
        duration: 1.5, 
        left: '25%', 
        top: '40%',
        ease: 'power2.out',
        onUpdate: function() {
            if (this.progress() % 0.1 < 0.01) {
                createTrailEffect('dog');
            }
        }
    }, 0);
    
    tl.to('#hawk-player', { 
        duration: 1, 
        left: '35%', 
        top: '70%',
        ease: 'power1.inOut',
        onUpdate: function() {
            if (this.progress() % 0.2 < 0.01) {
                createTrailEffect('hawk');
            }
        }
    }, 0);
    
    // Séquence 2: Dog force une erreur, Fox intercepte
    tl.to('#opponent1', { 
        duration: 1, 
        left: '20%', 
        top: '35%',
        ease: 'power1.inOut'
    }, 1.5);
    
    tl.to('#puck', { 
        duration: 1, 
        left: '20%', 
        top: '35%',
        ease: 'power1.inOut'
    }, 1.5);
    
    tl.to('#dog-player', { 
        duration: 0.8, 
        left: '20%', 
        top: '35%',
        ease: 'power2.out',
        onUpdate: function() {
            if (this.progress() % 0.2 < 0.01) {
                createTrailEffect('dog');
            }
        }
    }, 2.5);
    
    tl.to('#puck', { 
        duration: 0.3, 
        left: '30%', 
        top: '45%',
        ease: 'power4.out'
    }, 3.3);
    
    // Fox récupère et lance la contre-attaque
    tl.call(() => {
        updatePassingLanes('fox', 'hawk');
    }, null, 3.6);
    
    tl.to('#fox-player', { 
        duration: 1.5, 
        left: '45%', 
        top: '50%',
        ease: 'power2.inOut',
        onUpdate: function() {
            if (this.progress() % 0.2 < 0.01) {
                createTrailEffect('fox');
            }
        }
    }, 3.6);
    
    tl.to('#puck', { 
        duration: 1.5, 
        left: '45%', 
        top: '50%',
        ease: 'power2.inOut'
    }, 3.6);
    
    tl.to('#hawk-player', { 
        duration: 1.5, 
        left: '55%', 
        top: '65%',
        ease: 'power2.inOut',
        onUpdate: function() {
            if (this.progress() % 0.2 < 0.01) {
                createTrailEffect('hawk');
            }
        }
    }, 3.6);
    
    tl.to('#dog-player', { 
        duration: 1.5, 
        left: '50%', 
        top: '30%',
        ease: 'power2.inOut',
        onUpdate: function() {
            if (this.progress() % 0.2 < 0.01) {
                createTrailEffect('dog');
            }
        }
    }, 3.6);
    
    // Fox passe au Hawk
    tl.to('#puck', { 
        duration: 0.3, 
        left: '55%', 
        top: '65%',
        ease: 'power2.out'
    }, 5.1);
    
    // Retour aux positions initiales
    tl.to('#dog-player', { 
        duration: 1, 
        left: initialPositions.defensive.dog.left, 
        top: initialPositions.defensive.dog.top,
        ease: 'power1.inOut'
    }, 6);
    
    tl.to('#hawk-player', { 
        duration: 1, 
        left: initialPositions.defensive.hawk.left, 
        top: initialPositions.defensive.hawk.top,
        ease: 'power1.inOut'
    }, 6);
    
    tl.to('#fox-player', { 
        duration: 1, 
        left: initialPositions.defensive.fox.left, 
        top: initialPositions.defensive.fox.top,
        ease: 'power1.inOut'
    }, 6);
    
    tl.to('#puck', { 
        duration: 1, 
        left: initialPositions.defensive.puck.left, 
        top: initialPositions.defensive.puck.top,
        ease: 'power1.inOut'
    }, 6);
    
    // Mise à jour de la timeline
    tl.to('#timeline-progress', {
        width: '100%',
        duration: 7,
        ease: 'none'
    }, 0);
};

animations.transition = (tl) => {
    // Mise à jour des zones de couverture
    updateCoverageZones('transition');
    
    // Séquence 1: Dog récupère la rondelle
    tl.to('#dog-player', { 
        duration: 1, 
        left: '45%', 
        top: '40%',
        ease: 'power2.out',
        onUpdate: function() {
            if (this.progress() % 0.1 < 0.01) {
                createTrailEffect('dog');
            }
        }
    }, 0);
    
    tl.to('#puck', { 
        duration: 1, 
        left: '45%', 
        top: '40%',
        ease: 'power2.out'
    }, 0);
    
    // Hawk accélère en zone offensive
    tl.to('#hawk-player', { 
        duration: 1.5, 
        left: '70%', 
        top: '60%',
        ease: 'power3.in',
        onUpdate: function() {
            if (this.progress() % 0.1 < 0.01) {
                createTrailEffect('hawk');
            }
        }
    }, 0);
    
    // Fox se déplace vers le centre
    tl.to('#fox-player', { 
        duration: 1, 
        left: '55%', 
        top: '45%',
        ease: 'power1.inOut',
        onUpdate: function() {
            if (this.progress() % 0.2 < 0.01) {
                createTrailEffect('fox');
            }
        }
    }, 0);
    
    // Dog passe au Fox
    tl.call(() => {
        updatePassingLanes('dog', 'fox');
    }, null, 1);
    
    tl.to('#puck', { 
        duration: 0.3, 
        left: '55%', 
        top: '45%',
        ease: 'power4.out'
    }, 1);
    
    // Fox avance avec la rondelle
    tl.to('#fox-player', { 
        duration: 1.5, 
        left: '65%', 
        top: '50%',
        ease: 'power2.inOut',
        onUpdate: function() {
            if (this.progress() % 0.2 < 0.01) {
                createTrailEffect('fox');
            }
        }
    }, 1.3);
    
    tl.to('#puck', { 
        duration: 1.5, 
        left: '65%', 
        top: '50%',
        ease: 'power2.inOut'
    }, 1.3);
    
    // Dog se déplace en soutien
    tl.to('#dog-player', { 
        duration: 1.5, 
        left: '60%', 
        top: '30%',
        ease: 'power2.inOut',
        onUpdate: function() {
            if (this.progress() % 0.2 < 0.01) {
                createTrailEffect('dog');
            }
        }
    }, 1.3);
    
    // Fox passe au Hawk
    tl.call(() => {
        updatePassingLanes('fox', 'hawk');
    }, null, 2.8);
    
    tl.to('#puck', { 
        duration: 0.3, 
        left: '70%', 
        top: '60%',
        ease: 'power4.out'
    }, 2.8);
    
    // Hawk tire
    tl.call(() => {
        createShotTrajectory('hawk', '.goal-right');
    }, null, 3.1);
    
    tl.to('#puck', { 
        duration: 0.5, 
        left: '95%', 
        top: '50%',
        ease: 'power4.in'
    }, 3.1);
    
    // Retour aux positions initiales
    tl.to('#dog-player', { 
        duration: 1, 
        left: initialPositions.transition.dog.left, 
        top: initialPositions.transition.dog.top,
        ease: 'power1.inOut'
    }, 4);
    
    tl.to('#hawk-player', { 
        duration: 1, 
        left: initialPositions.transition.hawk.left, 
        top: initialPositions.transition.hawk.top,
        ease: 'power1.inOut'
    }, 4);
    
    tl.to('#fox-player', { 
        duration: 1, 
        left: initialPositions.transition.fox.left, 
        top: initialPositions.transition.fox.top,
        ease: 'power1.inOut'
    }, 4);
    
    tl.to('#puck', { 
        duration: 1, 
        left: initialPositions.transition.puck.left, 
        top: initialPositions.transition.puck.top,
        ease: 'power1.inOut'
    }, 4);
    
    // Mise à jour de la timeline
    tl.to('#timeline-progress', {
        width: '100%',
        duration: 5,
        ease: 'none'
    }, 0);
};

animations.powerplay = (tl) => {
    // Mise à jour des zones de couverture
    updateCoverageZones('powerplay');
    
    // Séquence 1: Fox contrôle au centre
    tl.to('#fox-player', { 
        duration: 1, 
        left: '65%', 
        top: '50%',
        ease: 'power1.inOut',
        onUpdate: function() {
            if (this.progress() % 0.2 < 0.01) {
                createTrailEffect('fox');
            }
        }
    }, 0);
    
    // Dog se positionne près du filet
    tl.to('#dog-player', { 
        duration: 1, 
        left: '85%', 
        top: '45%',
        ease: 'power1.inOut',
        onUpdate: function() {
            if (this.progress() % 0.2 < 0.01) {
                createTrailEffect('dog');
            }
        }
    }, 0);
    
    // Hawk se place dans le cercle de mise en jeu
    tl.to('#hawk-player', { 
        duration: 1, 
        left: '75%', 
        top: '65%',
        ease: 'power1.inOut',
        onUpdate: function() {
            if (this.progress() % 0.2 < 0.01) {
                createTrailEffect('hawk');
            }
        }
    }, 0);
    
    // Fox passe au défenseur
    tl.call(() => {
        updatePassingLanes('fox', 'defense1');
    }, null, 1);
    
    tl.to('#puck', { 
        duration: 0.3, 
        left: '85%', 
        top: '40%',
        ease: 'power2.out'
    }, 1);
    
    // Défenseur passe au Hawk
    tl.call(() => {
        updatePassingLanes('defense1', 'hawk');
    }, null, 1.5);
    
    tl.to('#puck', { 
        duration: 0.3, 
        left: '75%', 
        top: '65%',
        ease: 'power2.out'
    }, 1.5);
    
    // Hawk passe au Fox
    tl.call(() => {
        updatePassingLanes('hawk', 'fox');
    }, null, 2);
    
    tl.to('#puck', { 
        duration: 0.3, 
        left: '65%', 
        top: '50%',
        ease: 'power2.out'
    }, 2);
    
    // Fox passe au Dog pour un tir
    tl.call(() => {
        updatePassingLanes('fox', 'dog');
    }, null, 2.5);
    
    tl.to('#puck', { 
        duration: 0.3, 
        left: '85%', 
        top: '45%',
        ease: 'power2.out'
    }, 2.5);
    
    // Dog tire
    tl.call(() => {
        createShotTrajectory('dog', '.goal-right');
    }, null, 2.8);
    
    tl.to('#puck', { 
        duration: 0.4, 
        left: '95%', 
        top: '50%',
        ease: 'power3.in'
    }, 2.8);
    
    // Nouvelle configuration
    tl.to('#fox-player', { 
        duration: 1, 
        left: '70%', 
        top: '40%',
        ease: 'power1.inOut',
        onUpdate: function() {
            if (this.progress() % 0.2 < 0.01) {
                createTrailEffect('fox');
            }
        }
    }, 3.5);
    
    tl.to('#dog-player', { 
        duration: 1, 
        left: '80%', 
        top: '30%',
        ease: 'power1.inOut',
        onUpdate: function() {
            if (this.progress() % 0.2 < 0.01) {
                createTrailEffect('dog');
            }
        }
    }, 3.5);
    
    tl.to('#hawk-player', { 
        duration: 1, 
        left: '80%', 
        top: '70%',
        ease: 'power1.inOut',
        onUpdate: function() {
            if (this.progress() % 0.2 < 0.01) {
                createTrailEffect('hawk');
            }
        }
    }, 3.5);
    
    tl.to('#puck', { 
        duration: 0.5, 
        left: '70%', 
        top: '40%',
        ease: 'power1.inOut'
    }, 4);
    
    // Retour aux positions initiales
    tl.to('#dog-player', { 
        duration: 1, 
        left: initialPositions.powerplay.dog.left, 
        top: initialPositions.powerplay.dog.top,
        ease: 'power1.inOut'
    }, 5);
    
    tl.to('#hawk-player', { 
        duration: 1, 
        left: initialPositions.powerplay.hawk.left, 
        top: initialPositions.powerplay.hawk.top,
        ease: 'power1.inOut'
    }, 5);
    
    tl.to('#fox-player', { 
        duration: 1, 
        left: initialPositions.powerplay.fox.left, 
        top: initialPositions.powerplay.fox.top,
        ease: 'power1.inOut'
    }, 5);
    
    tl.to('#puck', { 
        duration: 1, 
        left: initialPositions.powerplay.puck.left, 
        top: initialPositions.powerplay.puck.top,
        ease: 'power1.inOut'
    }, 5);
    
    // Mise à jour de la timeline
    tl.to('#timeline-progress', {
        width: '100%',
        duration: 6,
        ease: 'none'
    }, 0);
};

animations['penalty-kill'] = (tl) => {
    // Mise à jour des zones de couverture
    updateCoverageZones('penalty-kill');
    
    // Séquence 1: Fox et Dog forment un duo défensif
    tl.to('#fox-player', { 
        duration: 1, 
        left: '30%', 
        top: '45%',
        ease: 'power1.inOut',
        onUpdate: function() {
            if (this.progress() % 0.2 < 0.01) {
                createTrailEffect('fox');
            }
        }
    }, 0);
    
    tl.to('#dog-player', { 
        duration: 1, 
        left: '25%', 
        top: '35%',
        ease: 'power1.inOut',
        onUpdate: function() {
            if (this.progress() % 0.2 < 0.01) {
                createTrailEffect('dog');
            }
        }
    }, 0);
    
    // L'adversaire contrôle la rondelle
    tl.to('#opponent2', { 
        duration: 1, 
        left: '15%', 
        top: '50%',
        ease: 'power1.inOut'
    }, 0);
    
    tl.to('#puck', { 
        duration: 1, 
        left: '15%', 
        top: '50%',
        ease: 'power1.inOut'
    }, 0);
    
    // Dog applique la pression
    tl.to('#dog-player', { 
        duration: 1, 
        left: '20%', 
        top: '45%',
        ease: 'power2.out',
        onUpdate: function() {
            if (this.progress() % 0.1 < 0.01) {
                createTrailEffect('dog');
            }
        }
    }, 1);
    
    // Fox couvre la passe
    tl.to('#fox-player', { 
        duration: 0.8, 
        left: '25%', 
        top: '55%',
        ease: 'power1.inOut',
        onUpdate: function() {
            if (this.progress() % 0.2 < 0.01) {
                createTrailEffect('fox');
            }
        }
    }, 1);
    
    // Dog force une erreur, Fox intercepte
    tl.to('#puck', { 
        duration: 0.3, 
        left: '25%', 
        top: '55%',
        ease: 'power4.out'
    }, 2);
    
    // Fox dégage la rondelle
    tl.call(() => {
        createShotTrajectory('fox', '.blue-line-right');
    }, null, 2.3);
    
    tl.to('#puck', { 
        duration: 0.8, 
        left: '70%', 
        top: '50%',
        ease: 'power3.in'
    }, 2.3);
    
    // Dog se déplace pour changer
    tl.to('#dog-player', { 
        duration: 1.5, 
        left: '40%', 
        top: '30%',
        ease: 'power1.inOut',
        onUpdate: function() {
            if (this.progress() % 0.2 < 0.01) {
                createTrailEffect('dog');
            }
        }
    }, 3.1);
    
    // Fox se déplace pour changer
    tl.to('#fox-player', { 
        duration: 1.5, 
        left: '40%', 
        top: '50%',
        ease: 'power1.inOut',
        onUpdate: function() {
            if (this.progress() % 0.2 < 0.01) {
                createTrailEffect('fox');
            }
        }
    }, 3.1);
    
    // Retour aux positions initiales
    tl.to('#dog-player', { 
        duration: 1, 
        left: initialPositions['penalty-kill'].dog.left, 
        top: initialPositions['penalty-kill'].dog.top,
        ease: 'power1.inOut'
    }, 4.6);
    
    tl.to('#fox-player', { 
        duration: 1, 
        left: initialPositions['penalty-kill'].fox.left, 
        top: initialPositions['penalty-kill'].fox.top,
        ease: 'power1.inOut'
    }, 4.6);
    
    tl.to('#puck', { 
        duration: 1, 
        left: initialPositions['penalty-kill'].puck.left, 
        top: initialPositions['penalty-kill'].puck.top,
        ease: 'power1.inOut'
    }, 4.6);
    
    // Mise à jour de la timeline
    tl.to('#timeline-progress', {
        width: '100%',
        duration: 5.6,
        ease: 'none'
    }, 0);
};

// Fonction pour initialiser les positions des joueurs
function initializePositions(scenario) {
    const positions = initialPositions[scenario];
    
    // Positionner les joueurs
    gsap.set('#dog-player', { left: positions.dog.left, top: positions.dog.top });
    gsap.set('#hawk-player', { left: positions.hawk.left, top: positions.hawk.top });
    gsap.set('#fox-player', { left: positions.fox.left, top: positions.fox.top });
    gsap.set('#defense-1', { left: positions.defense1.left, top: positions.defense1.top });
    gsap.set('#defense-2', { left: positions.defense2.left, top: positions.defense2.top });
    
    // Positionner les adversaires
    if (positions.opponent1) gsap.set('#opponent-1', { left: positions.opponent1.left, top: positions.opponent1.top });
    if (positions.opponent2) gsap.set('#opponent-2', { left: positions.opponent2.left, top: positions.opponent2.top });
    if (positions.opponent3) gsap.set('#opponent-3', { left: positions.opponent3.left, top: positions.opponent3.top });
    if (positions.opponent4) gsap.set('#opponent-4', { left: positions.opponent4.left, top: positions.opponent4.top });
    if (positions.opponent5) gsap.set('#opponent-5', { left: positions.opponent5.left, top: positions.opponent5.top });
    
    // Positionner la rondelle
    gsap.set('#puck', { left: positions.puck.left, top: positions.puck.top });
    
    // Réinitialiser les lignes de passes
    gsap.set('.passing-lane', { opacity: 0 });
    
    // Réinitialiser la trajectoire de tir
    gsap.set('#shot-trajectory', { opacity: 0 });
    
    // Mettre à jour les zones de couverture
    updateCoverageZones(scenario);
    
    // Réinitialiser la timeline
    gsap.set('#timeline-progress', { width: '0%' });
}

// Fonction pour créer et démarrer l'animation
function createAnimation(scenario) {
    // Arrêter l'animation précédente si elle existe
    if (timeline) {
        timeline.kill();
    }
    
    // Initialiser les positions
    initializePositions(scenario);
    
    // Créer une nouvelle timeline
    timeline = gsap.timeline({
        paused: true,
        repeat: -1,
        repeatDelay: 1,
        onRepeat: function() {
            // Réinitialiser les positions au début de chaque répétition
            initializePositions(scenario);
        }
    });
    
    // Ajouter les animations spécifiques au scénario
    if (animations[scenario]) {
        animations[scenario](timeline);
    }
    
    // Mettre à jour la vitesse
    timeline.timeScale(animationSpeed);
    
    return timeline;
}

// Fonction pour démarrer l'animation
function playAnimation() {
    if (!timeline || !isPlaying) {
        timeline = createAnimation(currentScenario);
        timeline.play();
        isPlaying = true;
    } else {
        timeline.play();
    }
}

// Fonction pour mettre en pause l'animation
function pauseAnimation() {
    if (timeline && isPlaying) {
        timeline.pause();
        isPlaying = false;
    }
}

// Fonction pour réinitialiser l'animation
function resetAnimation() {
    if (timeline) {
        timeline.kill();
    }
    
    timeline = createAnimation(currentScenario);
    
    if (isPlaying) {
        timeline.play();
    } else {
        timeline.pause(0);
    }
}

// Fonction pour changer de scénario
function changeScenario(scenario) {
    if (currentScenario !== scenario) {
        currentScenario = scenario;
        resetAnimation();
        
        // Mettre à jour l'interface utilisateur
        document.querySelectorAll('.scenario-btn').forEach(btn => {
            btn.classList.remove('active');
        });
        
        document.querySelectorAll(`.scenario-btn[data-scenario="${scenario}"]`).forEach(btn => {
            btn.classList.add('active');
        });
        
        document.querySelectorAll('.scenario-info').forEach(info => {
            info.classList.remove('active');
        });
        
        document.querySelector(`.${scenario}-info`).classList.add('active');
    }
}

// Fonction pour changer la vitesse de l'animation
function changeSpeed(speed) {
    animationSpeed = speed;
    if (timeline) {
        timeline.timeScale(speed);
    }
    
    // Mettre à jour l'affichage de la vitesse
    document.getElementById('speed-value').textContent = speed + 'x';
}

// Fonction pour basculer l'affichage des traînées
function toggleTrails(show) {
    showTrails = show;
}

// Fonction pour basculer l'affichage des lignes de passes
function togglePassingLanes(show) {
    showPassingLanes = show;
    
    if (!show) {
        gsap.to('.passing-lane', { opacity: 0, duration: 0.3 });
    }
}

// Fonction pour basculer l'affichage des zones de couverture
function toggleCoverageZones(show) {
    showCoverageZones = show;
    
    if (show) {
        updateCoverageZones(currentScenario);
    } else {
        gsap.to('.coverage-zone', { opacity: 0, duration: 0.3 });
    }
}

// Initialisation au chargement de la page
document.addEventListener('DOMContentLoaded', function() {
    // Initialiser les positions
    initializePositions(currentScenario);
    
    // Configurer les boutons de scénario
    document.querySelectorAll('.scenario-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            const scenario = this.getAttribute('data-scenario');
            changeScenario(scenario);
        });
    });
    
    // Configurer les boutons de lecture
    document.getElementById('play-btn').addEventListener('click', playAnimation);
    document.getElementById('pause-btn').addEventListener('click', pauseAnimation);
    document.getElementById('reset-btn').addEventListener('click', resetAnimation);
    
    // Configurer le slider de vitesse
    document.getElementById('speed-slider').addEventListener('input', function() {
        changeSpeed(parseFloat(this.value));
    });
    
    // Configurer les options d'affichage
    document.getElementById('show-trails').addEventListener('change', function() {
        toggleTrails(this.checked);
    });
    
    document.getElementById('show-passing-lanes').addEventListener('change', function() {
        togglePassingLanes(this.checked);
    });
    
    document.getElementById('show-coverage-zones').addEventListener('change', function() {
        toggleCoverageZones(this.checked);
    });
    
    // Configurer les onglets
    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            const tabId = this.getAttribute('data-tab');
            
            // Désactiver tous les onglets
            document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
            document.querySelectorAll('.tab-pane').forEach(p => p.classList.remove('active'));
            
            // Activer l'onglet sélectionné
            this.classList.add('active');
            document.getElementById(`${tabId}-tab`).classList.add('active');
        });
    });
    
    // Configurer les clics sur les joueurs
    document.getElementById('dog-player').addEventListener('click', function() {
        document.querySelectorAll('.role-details').forEach(d => d.classList.remove('active'));
        document.getElementById('dog-details').classList.add('active');
        document.getElementById('role-info').style.display = 'none';
        
        // Activer l'onglet des rôles
        document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
        document.querySelectorAll('.tab-pane').forEach(p => p.classList.remove('active'));
        document.querySelector('.tab-btn[data-tab="roles"]').classList.add('active');
        document.getElementById('roles-tab').classList.add('active');
    });
    
    document.getElementById('hawk-player').addEventListener('click', function() {
        document.querySelectorAll('.role-details').forEach(d => d.classList.remove('active'));
        document.getElementById('hawk-details').classList.add('active');
        document.getElementById('role-info').style.display = 'none';
        
        // Activer l'onglet des rôles
        document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
        document.querySelectorAll('.tab-pane').forEach(p => p.classList.remove('active'));
        document.querySelector('.tab-btn[data-tab="roles"]').classList.add('active');
        document.getElementById('roles-tab').classList.add('active');
    });
    
    document.getElementById('fox-player').addEventListener('click', function() {
        document.querySelectorAll('.role-details').forEach(d => d.classList.remove('active'));
        document.getElementById('fox-details').classList.add('active');
        document.getElementById('role-info').style.display = 'none';
        
        // Activer l'onglet des rôles
        document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
        document.querySelectorAll('.tab-pane').forEach(p => p.classList.remove('active'));
        document.querySelector('.tab-btn[data-tab="roles"]').classList.add('active');
        document.getElementById('roles-tab').classList.add('active');
    });
    
    // Configurer le bouton de retour au guide
    document.getElementById('back-to-guide').addEventListener('click', function(e) {
        e.preventDefault();
        window.location.href = '../index.html';
    });
    
    // Démarrer avec le scénario offensif
    changeScenario('offensive');
    
    // Animer les barres d'attributs
    gsap.to('.attribute-value', {
        width: function() {
            return this.getAttribute('style').split('width:')[1].split('%')[0] + '%';
        },
        duration: 1.5,
        ease: 'power2.out',
        stagger: 0.1
    });
});
