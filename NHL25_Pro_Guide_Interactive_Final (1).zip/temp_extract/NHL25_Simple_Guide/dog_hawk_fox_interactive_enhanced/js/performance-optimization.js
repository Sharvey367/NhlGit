// Script d'optimisation des performances pour le diagramme Dog-Hawk-Fox
// Améliore la réactivité et les performances de l'application

// Techniques d'optimisation implémentées:
// 1. Mise en cache des éléments DOM fréquemment utilisés
// 2. Throttling des événements intensifs
// 3. Optimisation des animations GSAP
// 4. Gestion efficace de la mémoire
// 5. Chargement différé des ressources

// Cache pour les éléments DOM fréquemment utilisés
const DOMCache = {
    players: {},
    controls: {},
    scenarios: {},
    tabs: {},
    initialized: false,
    
    // Initialiser le cache
    init: function() {
        if (this.initialized) return;
        
        // Mettre en cache les joueurs
        ['dog', 'hawk', 'fox', 'defense-1', 'defense-2', 'opponent-1', 'opponent-2', 
         'opponent-3', 'opponent-4', 'opponent-5', 'puck'].forEach(id => {
            this.players[id] = document.getElementById(`${id}-player`) || document.getElementById(id);
        });
        
        // Mettre en cache les contrôles
        this.controls.playBtn = document.getElementById('play-btn');
        this.controls.pauseBtn = document.getElementById('pause-btn');
        this.controls.resetBtn = document.getElementById('reset-btn');
        this.controls.speedSlider = document.getElementById('speed-slider');
        this.controls.speedValue = document.getElementById('speed-value');
        this.controls.showTrails = document.getElementById('show-trails');
        this.controls.showPassingLanes = document.getElementById('show-passing-lanes');
        this.controls.showCoverageZones = document.getElementById('show-coverage-zones');
        this.controls.timelineProgress = document.getElementById('timeline-progress');
        
        // Mettre en cache les boutons de scénario
        document.querySelectorAll('.scenario-btn').forEach(btn => {
            const scenario = btn.getAttribute('data-scenario');
            if (!this.scenarios[scenario]) {
                this.scenarios[scenario] = [];
            }
            this.scenarios[scenario].push(btn);
        });
        
        // Mettre en cache les onglets
        document.querySelectorAll('.tab-btn').forEach(btn => {
            const tab = btn.getAttribute('data-tab');
            this.tabs[tab] = {
                button: btn,
                pane: document.getElementById(`${tab}-tab`)
            };
        });
        
        this.initialized = true;
    }
};

// Fonction de throttling pour limiter la fréquence d'exécution des fonctions
function throttle(func, limit) {
    let inThrottle;
    return function() {
        const args = arguments;
        const context = this;
        if (!inThrottle) {
            func.apply(context, args);
            inThrottle = true;
            setTimeout(() => inThrottle = false, limit);
        }
    };
}

// Optimisation des animations GSAP
function optimizeGSAPAnimations() {
    // Configurer GSAP pour des performances optimales
    if (window.gsap) {
        // Utiliser force3D pour accélérer les animations
        gsap.config({
            force3D: true
        });
        
        // Préférer les transformations CSS aux propriétés left/top pour de meilleures performances
        const originalTo = gsap.to;
        gsap.to = function(target, vars) {
            // Si les propriétés left/top sont utilisées et que la cible est un élément DOM
            if ((vars.left !== undefined || vars.top !== undefined) && 
                (typeof target === 'string' || target instanceof Element || 
                 (target instanceof Array && target[0] instanceof Element))) {
                
                // Convertir left/top en transformations x/y pour de meilleures performances
                const newVars = {...vars};
                
                if (newVars.left !== undefined) {
                    newVars.xPercent = 0;
                    newVars.x = newVars.left;
                    delete newVars.left;
                }
                
                if (newVars.top !== undefined) {
                    newVars.yPercent = 0;
                    newVars.y = newVars.top;
                    delete newVars.top;
                }
                
                return originalTo.call(this, target, newVars);
            }
            
            return originalTo.apply(this, arguments);
        };
    }
}

// Gestion efficace de la mémoire
function implementMemoryManagement() {
    // Nettoyer les animations et les événements non utilisés
    function cleanupUnusedResources() {
        // Tuer les anciennes animations qui ne sont plus nécessaires
        if (window.timeline && !window.isPlaying) {
            window.timeline.kill();
            window.timeline = null;
        }
        
        // Nettoyer les effets de traînée
        const trailEffects = document.querySelectorAll('.trail-effect');
        if (trailEffects.length > 20) {  // Limiter le nombre d'effets de traînée
            for (let i = 0; i < trailEffects.length - 20; i++) {
                if (trailEffects[i].parentNode) {
                    trailEffects[i].parentNode.removeChild(trailEffects[i]);
                }
            }
        }
    }
    
    // Exécuter le nettoyage périodiquement
    setInterval(cleanupUnusedResources, 10000);  // Toutes les 10 secondes
    
    // Nettoyer avant de changer de scénario
    const originalChangeScenario = window.changeScenario;
    if (originalChangeScenario) {
        window.changeScenario = function(scenario) {
            cleanupUnusedResources();
            return originalChangeScenario.apply(this, arguments);
        };
    }
}

// Chargement différé des ressources
function implementLazyLoading() {
    // Charger les scénarios supplémentaires uniquement lorsqu'ils sont nécessaires
    function lazyLoadScenarios() {
        // Vérifier si les scénarios supplémentaires sont déjà chargés
        if (window.additionalScenariosLoaded) return;
        
        // Charger le script des scénarios supplémentaires
        const script = document.createElement('script');
        script.src = 'js/additional-scenarios.js';
        script.onload = function() {
            window.additionalScenariosLoaded = true;
            console.log('Scénarios supplémentaires chargés avec succès');
        };
        document.head.appendChild(script);
    }
    
    // Charger les scénarios après un court délai pour ne pas bloquer le chargement initial
    setTimeout(lazyLoadScenarios, 1000);
}

// Optimisation des gestionnaires d'événements
function optimizeEventHandlers() {
    // Utiliser la délégation d'événements pour réduire le nombre d'écouteurs
    function implementEventDelegation() {
        // Supprimer les écouteurs individuels des boutons de scénario
        document.querySelectorAll('.scenario-btn').forEach(btn => {
            btn.removeEventListener('click', btn.scenarioClickHandler);
        });
        
        // Ajouter un seul écouteur au conteneur parent
        const scenarioSelector = document.querySelector('.scenario-selector');
        if (scenarioSelector) {
            scenarioSelector.addEventListener('click', function(e) {
                if (e.target.classList.contains('scenario-btn')) {
                    const scenario = e.target.getAttribute('data-scenario');
                    if (typeof window.changeScenario === 'function') {
                        window.changeScenario(scenario);
                    }
                }
            });
        }
        
        // Faire de même pour les onglets
        const panelTabs = document.querySelector('.panel-tabs');
        if (panelTabs) {
            panelTabs.addEventListener('click', function(e) {
                if (e.target.classList.contains('tab-btn')) {
                    const tabId = e.target.getAttribute('data-tab');
                    
                    // Désactiver tous les onglets
                    document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
                    document.querySelectorAll('.tab-pane').forEach(p => p.classList.remove('active'));
                    
                    // Activer l'onglet sélectionné
                    e.target.classList.add('active');
                    document.getElementById(`${tabId}-tab`).classList.add('active');
                }
            });
        }
    }
    
    // Optimiser les gestionnaires d'événements pour les contrôles de lecture
    function optimizePlaybackControls() {
        // Utiliser un seul gestionnaire pour les contrôles de lecture
        const playbackControls = document.querySelector('.playback-controls');
        if (playbackControls) {
            playbackControls.addEventListener('click', function(e) {
                if (e.target.closest('#play-btn')) {
                    if (typeof window.playAnimation === 'function') {
                        window.playAnimation();
                    }
                } else if (e.target.closest('#pause-btn')) {
                    if (typeof window.pauseAnimation === 'function') {
                        window.pauseAnimation();
                    }
                } else if (e.target.closest('#reset-btn')) {
                    if (typeof window.resetAnimation === 'function') {
                        window.resetAnimation();
                    }
                }
            });
        }
        
        // Optimiser le slider de vitesse avec throttling
        const speedSlider = document.getElementById('speed-slider');
        if (speedSlider) {
            speedSlider.removeEventListener('input', speedSlider.inputHandler);
            
            const throttledSpeedChange = throttle(function(e) {
                if (typeof window.changeSpeed === 'function') {
                    window.changeSpeed(parseFloat(e.target.value));
                }
            }, 50);  // Limiter à une exécution toutes les 50ms
            
            speedSlider.addEventListener('input', throttledSpeedChange);
            speedSlider.inputHandler = throttledSpeedChange;
        }
    }
    
    // Optimiser les interactions avec les joueurs
    function optimizePlayerInteractions() {
        // Utiliser la délégation d'événements pour les joueurs
        const rink = document.querySelector('.rink');
        if (rink) {
            rink.addEventListener('click', function(e) {
                const player = e.target.closest('.player');
                if (!player) return;
                
                const playerId = player.id;
                let roleId = '';
                
                if (playerId.includes('dog')) {
                    roleId = 'dog-details';
                } else if (playerId.includes('hawk')) {
                    roleId = 'hawk-details';
                } else if (playerId.includes('fox')) {
                    roleId = 'fox-details';
                } else {
                    return;
                }
                
                // Mettre à jour l'affichage des détails du rôle
                document.querySelectorAll('.role-details').forEach(d => d.classList.remove('active'));
                document.getElementById(roleId).classList.add('active');
                document.getElementById('role-info').style.display = 'none';
                
                // Activer l'onglet des rôles
                document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
                document.querySelectorAll('.tab-pane').forEach(p => p.classList.remove('active'));
                document.querySelector('.tab-btn[data-tab="roles"]').classList.add('active');
                document.getElementById('roles-tab').classList.add('active');
            });
        }
    }
    
    // Implémenter toutes les optimisations d'événements
    implementEventDelegation();
    optimizePlaybackControls();
    optimizePlayerInteractions();
}

// Optimisation du rendu
function optimizeRendering() {
    // Utiliser requestAnimationFrame pour les mises à jour visuelles
    function optimizeVisualUpdates() {
        // Remplacer les mises à jour directes par requestAnimationFrame
        const originalUpdateCoverageZones = window.updateCoverageZones;
        if (originalUpdateCoverageZones) {
            window.updateCoverageZones = function(scenario) {
                requestAnimationFrame(() => {
                    originalUpdateCoverageZones.call(this, scenario);
                });
            };
        }
        
        const originalUpdatePassingLanes = window.updatePassingLanes;
        if (originalUpdatePassingLanes) {
            window.updatePassingLanes = function(from, to, visible) {
                requestAnimationFrame(() => {
                    originalUpdatePassingLanes.call(this, from, to, visible);
                });
            };
        }
    }
    
    // Réduire les reflows et repaints
    function reduceReflowsAndRepaints() {
        // Grouper les modifications DOM
        const originalCreateTrailEffect = window.createTrailEffect;
        if (originalCreateTrailEffect) {
            window.createTrailEffect = function(player) {
                // Désactiver si les traînées sont désactivées
                if (!window.showTrails) return;
                
                const playerElement = document.getElementById(`${player}-player`);
                if (!playerElement) return;
                
                const trail = playerElement.querySelector('.player-trail');
                if (!trail) return;
                
                // Créer le fragment pour toutes les modifications
                const fragment = document.createDocumentFragment();
                
                // Créer un élément de traînée
                const trailEffect = document.createElement('div');
                trailEffect.className = 'trail-effect';
                trailEffect.style.width = '100%';
                trailEffect.style.height = '100%';
                trailEffect.style.borderRadius = '50%';
                trailEffect.style.position = 'absolute';
                trailEffect.style.backgroundColor = window.getComputedStyle(playerElement).backgroundColor;
                trailEffect.style.opacity = '0.5';
                
                fragment.appendChild(trailEffect);
                
                // Appliquer toutes les modifications en une seule fois
                trail.appendChild(fragment);
                
                // Animer la traînée
                gsap.to(trailEffect, {
                    opacity: 0,
                    scale: 0.5,
                    duration: 0.8,
                    onComplete: function() {
                        if (trailEffect.parentNode) {
                            trailEffect.parentNode.removeChild(trailEffect);
                        }
                    }
                });
            };
        }
    }
    
    // Implémenter toutes les optimisations de rendu
    optimizeVisualUpdates();
    reduceReflowsAndRepaints();
}

// Optimisation pour les appareils mobiles
function optimizeMobileExperience() {
    // Détecter les appareils mobiles
    const isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
    
    if (isMobile) {
        // Simplifier les animations sur mobile
        if (window.createTrailEffect) {
            const originalCreateTrailEffect = window.createTrailEffect;
            window.createTrailEffect = function(player) {
                // Réduire la fréquence des effets de traînée sur mobile
                if (Math.random() > 0.3) return;  // Seulement 30% des traînées
                
                originalCreateTrailEffect.call(this, player);
            };
        }
        
        // Optimiser les interactions tactiles
        function enhanceTouchInteractions() {
            // Ajouter une classe mobile au body
            document.body.classList.add('mobile-device');
            
            // Augmenter la taille des éléments interactifs
            const style = document.createElement('style');
            style.textContent = `
                .mobile-device .player {
                    width: 42px !important;
                    height: 42px !important;
                }
                
                .mobile-device .control-btn,
                .mobile-device .scenario-btn,
                .mobile-device .tab-btn {
                    padding: 12px 20px !important;
                    margin: 8px !important;
                }
                
                .mobile-device .toggle input[type="checkbox"] {
                    width: 50px !important;
                    height: 25px !important;
                }
                
                .mobile-device .toggle input[type="checkbox"]::before {
                    width: 21px !important;
                    height: 21px !important;
                }
                
                .mobile-device .toggle input[type="checkbox"]:checked::before {
                    transform: translateX(25px) !important;
                }
            `;
            document.head.appendChild(style);
        }
        
        enhanceTouchInteractions();
    }
}

// Fonction principale d'optimisation
function optimizePerformance() {
    console.log('Optimisation des performances en cours...');
    
    // Initialiser le cache DOM
    DOMCache.init();
    
    // Optimiser les animations GSAP
    optimizeGSAPAnimations();
    
    // Implémenter la gestion de la mémoire
    implementMemoryManagement();
    
    // Implémenter le chargement différé
    implementLazyLoading();
    
    // Optimiser les gestionnaires d'événements
    optimizeEventHandlers();
    
    // Optimiser le rendu
    optimizeRendering();
    
    // Optimiser pour les appareils mobiles
    optimizeMobileExperience();
    
    console.log('Optimisation des performances terminée');
}

// Exécuter l'optimisation au chargement de la page
document.addEventListener('DOMContentLoaded', function() {
    // Attendre un court instant pour ne pas bloquer le chargement initial
    setTimeout(optimizePerformance, 500);
});
